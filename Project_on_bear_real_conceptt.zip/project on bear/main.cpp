#include <iostream>

int main() {
    setlocale(LC_ALL , "RU");
    int num = -45;
    std::cout << "переменная:" << num << std::endl;
    std::cout << "Hello, world!\n";
    float a ;
    std::cout << "ваша переменна a : ";
    std::cin >> a;
    float b ;
    std::cout << "ваша переменна b : ";
    std::cin >> b;
    char s ;
    std::cout << "ваша знак: ";
    std::cin >> s;
    float c;

    if (s == '+'){
       c = a + b ;
       std::cout << c <<std::endl;
       if (a == 52){
         std::cout <<"52"<< std::endl;
       } 
    }
    else if (s == '-'){
        c = a - b ;
        std::cout << c ; 
    }
    else if (s == '*'){

        c = a * b ;
        std::cout << c ; 
    }
    else if (s == ':'){

        c = a / b ;
        std::cout << c ; 
    }

    else {
        std::cout << "знак не дествительный" ;
    }
    // std::cout << c ; 
    return 0;
}