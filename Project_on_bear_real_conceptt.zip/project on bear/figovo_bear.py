#import pygame
#import random
#import os
#import figovo_enemy
#PLATFORM_WIDTH = 50
#PLATFORM_HEIGHT = 50
#PLATFORM_COLOR = "#FF6262"
#SCREEN_WIDTH = 800
#SCREEN_HEIGHT = 600
#
#path=str(os.getcwd())
#
#enemy_zona_x_min= 50 
#enemy_zona_x_max = 100
#enemy_zona_y_min = 50
#enemy_zona_y_max = 100
#
#enemy_life_max = 2
#enemy_life= 2
#enemy_life_sneek = 3
#
#class Bear(pygame.sprite.Sprite):
#    def __init__(self, object, health, speed, pose,reload,time_last):
#        pygame.sprite.Sprite.__init__(self)
#        self.object = object
#        self.health = health
#        self.speed = speed
#        self.pose = pose
#        self.reload = reload
#        self.time_last=time_last
#        
#        # self.rect= pygame.Rect(x, y, 50, 50)
#        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
#        self.image.fill(pygame.Color(PLATFORM_COLOR))
#        self.image = pygame.image.load(f"{path}\\медведь.png")#enemy.pngalian
#        self.image = pygame.transform.scale (self.image, (50, 50))
#        self.rect = pygame.Rect(random.randint(enemy_zona_x_min,enemy_zona_x_max ), random.randint(enemy_zona_y_min, enemy_zona_y_max), 50, 50) 
#    def sprite_killer(sprite_):
#        sprite_.kill()
#
#
#
#
#enemy_cubes = ([pygame.Rect(random.randint(enemy_zona_x_min, enemy_zona_x_max), random.randint(enemy_zona_y_min, enemy_zona_y_max), 50, 50)]for _ in range(enemy_life) )
#enemy_massa = [figovo_enemy.NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes]
#enemy_zona_massa=[]
#enemy_zona_massa.append(enemy_zona_x_min)
#enemy_zona_massa.append(enemy_zona_x_max)
#enemy_zona_massa.append(enemy_zona_y_min)
#enemy_zona_massa.append(enemy_zona_y_max)
import pygame
import random
import os
import math  # Добавляем для вычислений

PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

current_dir = os.path.dirname(os.path.abspath(__file__))
path = current_dir

enemy_zona_x_min = 50 
enemy_zona_x_max = 100
enemy_zona_y_min = 50
enemy_zona_y_max = 100

enemy_life_max = 2
enemy_life = 2
enemy_life_sneek = 3

class Bear(pygame.sprite.Sprite):
    def __init__(self, object, health, speed, pose, reload, time_last):
        pygame.sprite.Sprite.__init__(self)
        self.object = object
        self.health = health
        self.speed = speed
        self.pose = pose
        self.reload = reload
        self.time_last = time_last
        
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        
        try:
            bear_image_path = os.path.join(path, "медведь.png")
            self.image = pygame.image.load(bear_image_path)
        except FileNotFoundError:
            print(f"Файл медведь.png не найден по пути: {path}")
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image.fill((139, 69, 19))
            
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = pygame.Rect(random.randint(enemy_zona_x_min, enemy_zona_x_max), 
                               random.randint(enemy_zona_y_min, enemy_zona_y_max), 50, 50)
    
    def update_ai(self, player, platforms, bear_massa, current_time):
        """AI для медведя - преследование игрока"""
        
        # Проверяем расстояние до игрока
        distance_to_player = self.calculate_distance(player)
        
        # Если игрок в радиусе 500 пикселей - преследуем
        if distance_to_player < 500:
            self.chase_player(player, platforms, bear_massa)
        else:
            # Случайное блуждание
            self.random_wander(platforms, bear_massa)
    
    def calculate_distance(self, player):
        """Вычисляет расстояние до игрока"""
        dx = player.object.x - self.rect.x
        dy = player.object.y - self.rect.y
        return math.sqrt(dx*dx + dy*dy)
    
    def chase_player(self, player, platforms, bear_massa):
        """Преследование игрока"""
        dx = player.object.x - self.rect.x
        dy = player.object.y - self.rect.y
        distance = max(math.sqrt(dx*dx + dy*dy), 0.1)
        
        # Нормализуем направление
        dx /= distance
        dy /= distance
        
        # Сохраняем старую позицию для отката при столкновении
        old_x, old_y = self.rect.x, self.rect.y
        
        # Двигаемся к игроку
        self.rect.x += dx * self.speed
        self.rect.y += dy * self.speed
        
        # Проверяем столкновения со стенами
        if self.check_collision_with_platforms(platforms):
            self.rect.x, self.rect.y = old_x, old_y
        
        # Избегаем столкновений с другими медведями
        self.avoid_other_bears(bear_massa)
    
    def random_wander(self, platforms, bear_massa):
        """Случайное блуждание когда игрок далеко"""
        if random.random() < 0.02:  # 2% chance сменить направление каждый кадр
            angle = random.uniform(0, 2 * math.pi)
            self.wander_direction = [math.cos(angle), math.sin(angle)]
        
        # Сохраняем старую позицию
        old_x, old_y = self.rect.x, self.rect.y
        
        # Двигаемся в случайном направлении
        if hasattr(self, 'wander_direction'):
            self.rect.x += self.wander_direction[0] * self.speed * 0.5
            self.rect.y += self.wander_direction[1] * self.speed * 0.5
            
            # Проверяем столкновения
            if self.check_collision_with_platforms(platforms):
                self.rect.x, self.rect.y = old_x, old_y
                # Меняем направление при столкновении
                angle = random.uniform(0, 2 * math.pi)
                self.wander_direction = [math.cos(angle), math.sin(angle)]
        
        # Избегаем других медведей
        self.avoid_other_bears(bear_massa)
    
    def check_collision_with_platforms(self, platforms):
        """Проверяет столкновения с платформами"""
        for platform in platforms:
            if platform.colision and self.rect.colliderect(platform.rect):
                return True
        return False
    
    def avoid_other_bears(self, bear_massa):
        """Избегание столкновений с другими медведями"""
        avoidance_force = [0, 0]
        
        for other in bear_massa:
            if other != self:
                dx = self.rect.x - other.rect.x
                dy = self.rect.y - other.rect.y
                distance = math.sqrt(dx*dx + dy*dy)
                
                if distance < 100 and distance > 0:
                    force = (100 - distance) / 100
                    avoidance_force[0] += (dx / distance) * force * 3
                    avoidance_force[1] += (dy / distance) * force * 3
        
        # Применяем силу избегания
        if avoidance_force[0] != 0 or avoidance_force[1] != 0:
            self.rect.x += avoidance_force[0]
            self.rect.y += avoidance_force[1]
    
    def check_distance_atack(self, player):
        """Проверяет возможность атаковать игрока"""
        distance = self.calculate_distance(player)
        return distance <= 85
    
    def attack_player(self, player, current_time):
        """Атака игрока"""
        if self.check_distance_atack(player):
            if current_time - self.time_last > self.reload:
                player.health -= 10  # Медведь наносит больше урона
                print("Медведь атаковал игрока!")
                self.time_last = current_time
    
    def sprite_killer(sprite_):
        sprite_.kill()

enemy_zona_massa = []
enemy_zona_massa.append(enemy_zona_x_min)
enemy_zona_massa.append(enemy_zona_x_max)
enemy_zona_massa.append(enemy_zona_y_min)
enemy_zona_massa.append(enemy_zona_y_max)