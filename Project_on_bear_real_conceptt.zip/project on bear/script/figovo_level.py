import pygame
import os
# from  figovo_17 import enemy_massa
import figovo_player 
import figovo_enemy
path=str(os.getcwd())
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
ICON_DIR = os.path.dirname(__file__) #  Полный путь к каталогу с файламиPLATFORM_WIDTH = 50

# activ_pf2= []


# level_glav.massa_act.append(d1)
# level_interier_1.massa_act.append(d1_v)

# Level_now=level_glav
def check_distance_activate(play, pf):
        
        if pf.click:
            distance = ((play.object[0] - pf.rect[0]) ** 2 + (play.object[1] - pf.rect[1])  ** 2) ** 0.5
            if distance <= 60:
                print("activatre 'e' ")
            
                return True
        else:
            return False


            # enemy_massa.remove(enemy)
            # Entities.remove(enemy)
            # for i in platforms:
            #         Sten.remove(i)
            #         Sten.add(i)
            # print("activate")



class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y , col ):
        pygame.sprite.Sprite.__init__(self)
        self.object=pygame.Rect(x, y, 50,50)
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        
        if col == "-":
            self.image = pygame.image.load(f"{path}\\camen.png")#camen.pngplatform
            self.colision=True
            self.click=False
        if col == "i":
            self.image = pygame.image.load(f"{path}\\tree.png")
            self.colision=True
            self.click=False
        if col == "w" :
            self.image = pygame.image.load(f"{path}\\trava.png")
            self.colision=False
            self.click=False
        if col == "o" :
            self.image = pygame.image.load(f"{path}\\dom1.png")
            self.colision=True
            # self.rect =  pygame.Rect( x, y ,PLATFORM_WIDTH , PLATFORM_HEIGHT )
            self.click=True
        if col == "x" :
            self.image = pygame.image.load(f"{path}\\dom1_kr.png")
            self.colision=True
            self.click=False
        if col == "l" :
            self.image = pygame.image.load(f"{path}\\dom1_bok.png")
            self.colision=True
            self.click=False
        if col == "t" :
            self.image = pygame.image.load(f"{path}\\tropa.png")
            self.colision=False
            self.click=False
        if col == "6" :
            self.image = pygame.image.load(f"{path}\\interier_stena.png")
            self.colision=True
            self.click=False
        if col == "8" :
            self.image = pygame.image.load(f"{path}\\interier_stena_gr.png")
            self.colision=True
            self.click=False
        if col == "4" :
            self.image = pygame.image.load(f"{path}\\interier_stena_vr.png")
            self.colision=True
            self.click=False
        if col == "2" :
            self.image = pygame.image.load(f"{path}\\interier_stena4.png")
            self.colision=True
            self.click=False
        if col == "3" :
            self.image = pygame.image.load(f"{path}\\interier_ugl1.png")
            self.colision=True
            self.click=False
        if col == "9" :
            self.image = pygame.image.load(f"{path}\\interier_ugl2.png")
            self.colision=True
            self.click=False
        if col == "7" :
            self.image = pygame.image.load(f"{path}\\interier_ugl3.png")
            self.colision=True
            self.click=False
        if col == "1" :
            self.image = pygame.image.load(f"{path}\\interier_ugl4.png")
            self.colision=True
            self.click=False
        if col == "5" :
            self.image = pygame.image.load(f"{path}\\interier_pol.png")
            self.colision=False
            self.click=False
  
  
  
        self.image = pygame.transform.scale (self.image, (PLATFORM_WIDTH, PLATFORM_HEIGHT ))
        self.rect = pygame.Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)
class Activ_click(Platform):
    def __init__(self ,x , y ,col ,  number , level_number , p_x , p_y , n_x , n_y)   :
        Platform.__init__(self ,x , y ,col )
        self.number= number 
        self.level_number = level_number
        self.p_x=p_x
        self.p_y=p_y 
        self.n_x = n_x
        self.n_y = n_y
activ_pf = []
level_massa = []
reset=1
class Level():
    def __init__(self , level_map , massa_vr , massa_act , player_x , player_y):
        self.level_map = level_map
        self.massa_vr = massa_vr
        self.massa_act = massa_act
        self.player_x = player_x
        self.player_y = player_y
    def enemy_massa(self , Enteties =pygame.sprite.Group()):
        Enteties.add(self.massa_vr)
def draw_level( level , Sten , platforms):
    
    # for pf in level:
        x = y = 0 # координаты
        for row in level.level_map: # вся строка
            for col in row: # каждый символ
                if  col != " ":
                    pf = Platform(x,y, col )
                    pf.object=pf.rect
                    Sten.add(pf)
                    platforms.append(pf)
                    # if pf.click:
                    #     activ_pf.append(pf)


                x += PLATFORM_WIDTH #блоки платформы ставятся на ширине блоков
            y += PLATFORM_HEIGHT    #то же самое и с высотой
            x = 0                   #на каждой новой строчке начинаем с нуля
level1 = ([
        "------------------------------------------------",   
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwiwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwxlwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwowwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "------------------------------------------------"])
level2 =([  
        "444444444444",
        "855555555558",
        "855555555558",
        "855555555558",
        "444444444444",
        ""])
level3 =([
        "",   
        "444444444444",
        "8555555555555555555558",
        "8555555555555555555558",
        "8555555555555555555558",
        "444444444444",
        ""])
level = ([
        "------------------------------------------------",   
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwiwwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwxlwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwowwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
        "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwww12345-",
        "------------------------------------------------" ])
level_massa.append(level1 )
level_massa.append(level2) 
# d1 = Activ_click(500,500 , 'o' , 1 , level2 , 80 , 60 , 500 , 500)
# activ_pf.append(d1)
# d1_v =Activ_click(50,50 , 'o' , 1 , level3 , 80 , 60 , 50 , 50)
# activ_pf.append(d1_v)
def level_reset( player , level_class , Sten , platforms , level_now ,Entities  ):#level , level_ , Platform , Sten , platforms , x_p, y_p , player
    level_now = level_class.level_map
    for _ in range(10):
        for i in platforms:
            platforms.remove(i)
            Sten.remove(i)
        
        print(f"plat: {platforms}")
        for row in level:
            for col in row:
                for i in col:
                    col.replace(i ,"" )
    for enemy in level_class.massa_vr:
        print(Entities)
        Entities.add(enemy)
    # level_class.enemy_massa(Entities)
    # reset_enemy_massa(enemy_massa , level_class.massa_vr)    
    # reset_activ_pf(activ_pf , level_class.massa_act)

    
    draw_level(level_now , Sten , platforms)
    player.object.x = level_class.player_x#figovo_player.
    player.object.y = level_class.player_y#figovo_player.
def activate(player , Sten , platforms ,level_now , Entities , level_dict):#activ_pf , enemy_massa , Sten , platforms 
    # for level_ in Level_now.massa_act : 
        for pf in  level_now.massa_act:
            if check_distance_activate(player , pf):
                level_reset(player ,level_dict[pf.level_number], Sten , platforms  , level_now ,  Entities )# , Platform , Sten , platforms level , pf.level_number , Platform , Sten , platforms ,  pf.p_x , pf.p_y , player
                # if len(enemy_massa)>0:
                #     # for enemy in figovo_enemy.enemy_massa:
                #     #     enemy.health = 0 #>c
                #     #     # print(enemy_massa)
                #     #     # enemy_massa.remove(enemy)
                #     #     print("враг умер")


def reset_enemy_massa(enemy_massa , enemy_massa_number):
    enemy_massa == enemy_massa_number

def reset_activ_pf(activ_pf , activ_pf_number):
    activ_pf == activ_pf_number

def reset_level_platform(platform):
    for i in platform:
        platform.remove(i)
# level_c_1 = Level(level1 , enemy) 

# d1 = Activ_click(500,500 , 'o' , 1 , level2 , 80 , 60 , 500 , 500)

# d1_v =figovo_level.Activ_click(50,50 , 'o' , 1 , "level_glav" , 80 , 60 , 50 , 50)


# level_glav =  Level(level1 , enemy_massa1 , [] , 80 ,80)
# level_interier_1 = Level(figovo_level.level2 , enemy_massa2 , [] , 60 ,60)
# level_dict = {"level_glav" = level_glav





    