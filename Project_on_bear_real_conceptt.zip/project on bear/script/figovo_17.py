#Figovo - 17
import pygame
import random
import sys
import numpy as np
import time
import os
import figovo_level 
import figovo_player
import figovo_enemy
import figovo_bear

pygame.init()

# Set up the screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PLAYER_SPEED = 5
WALL_SPEED = 1
RED = "RED"
BLUE = (0, 0, 255)
YELLOW = (209, 178, 23)
GREY = (130, 129, 122)
BALL_COLOR = (255, 0, 0)
BALL_RADIUS = 5
BACKGROUND_COLOR = "GREEN"
path=str(os.getcwd())
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
screen.fill(BACKGROUND_COLOR)
i_s = 1
objects_ = []
balls = []
# animation_set = [pygame.image.load(f"r{i}.png") for i in range(1, 6)]
time_now=1729865614.3516421  #(time.time())
print(time_now)
time_reload=0.5
time_last_shoot=0

damage_player=50
quantity_balls=100
time_last_spawn=0
time_reload_enemy=5
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
ICON_DIR = os.path.dirname(__file__) #  Полный путь к каталогу с файлами
Entities = pygame.sprite.Group() # Все объекты
Sten = pygame.sprite.Group() # Все объекты
level_now = []
activ_pf = []
level_massa = []
reset=1

counter_health_player_shrift = pygame.font.SysFont('serif', 28)
entities = pygame.sprite.Group() # Все объекты
Entities = pygame.sprite.Group() # Все объекты
platforms = [] # то, во что мы будем врезаться или опираться
untities = pygame.sprite.Group()
  


player_cube = pygame.Rect(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 50, 50,)#player_sprite((SCREEN_WIDTH / 2) , (SCREEN_HEIGHT / 2))
player = figovo_player.Player(player_cube, 100, 5,[SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2], 0 , 0 , pygame.Surface((50, 50))  )
player.object = player.rect
player.object.center = (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)


enemy_cubes1 = ([pygame.Rect(random.randint(figovo_enemy.enemy_zona_x_min, figovo_enemy.enemy_zona_x_max), random.randint(figovo_enemy.enemy_zona_y_min, figovo_enemy.enemy_zona_y_max), 50, 50)]for _ in range(figovo_enemy.enemy_life) )
enemy_massa1 = [figovo_enemy.NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes1]
enemy_massa2=[]
enemy_zona_massa=[]
enemy_massa=[]
enemy_massa2=[]

bear1 = ([pygame.Rect(random.randint(500, 1000), random.randint(1000,1500), 50, 50)]for _ in range(figovo_enemy.enemy_life) )
bear_massa = [figovo_bear.Bear(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in bear1]
 
# Set up the title of the windows
pygame.display.set_caption("Cube Game")


activ_pf2= []



d1 = figovo_level.Activ_click(500,500 , 'o' , 1 , 'level_interier_1' , 80 , 60 , 500 , 500) 
d1_v =figovo_level.Activ_click(50,50 , 'o' , 1 , "level_glav" , 80 , 60 , 50 , 50)


level_glav =  figovo_level.Level(figovo_level.level1 , enemy_massa1 , [] , 80 ,80)
level_interier_1 = figovo_level.Level(figovo_level.level2 , enemy_massa2 , [] , 60 ,60)
level_dict = {("level_glav") : level_glav,
              ('level_interier_1') : level_interier_1
              }
level_glav.massa_act.append(d1)
level_interier_1.massa_act.append(d1_v)

Level_now=level_glav
    

class SNARYAD(pygame.sprite.Sprite):
    def __init__(self, speed_X, speed_Y ):
        pygame.sprite.Sprite.__init__( self )


        self.speed_X=speed_X
        self.speed_Y=speed_Y
                
        self.image = pygame.Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT ))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        self.image = pygame.image.load(f"{path}\\fireball.png")
        self.image = pygame.transform.scale (self.image, (25, 25))
        self.object=self.rect = pygame.Rect(player.object[0] + player.object[2] // 2,
                                              player.object[1] + player.object[3] // 2, 5,5) #pygame.Rect(x_c, y_c, 5, 5)
     
    def move(self):
        self.rect[0] += self.speed_X
        self.rect[1] += self.speed_Y
COLOR =  "#888888"  
class Level_class():
    def __init__ (self , mapa , number):
        self.mapa = mapa
        self.number = number


objects_.append(player)
x_c = [player.rect[0]]
y_c = [player.rect[1]]




for i in enemy_massa:
    i.object = i.rect
   
    Entities.add(i)
    objects_.append(i)
def draw_circle(x,y):
    pygame.draw.circle(screen,(0, 0, 255), (x_c, y_c),40)
    if pygame.key.get_pressed()[pygame.K_UP]:
        x_c += x
        y_c += y
    if pygame.key.get_pressed()[pygame.K_DOWN]:
        x_c += x
        y_c += y
level_massa.append(figovo_level.level1 )
level_massa.append(figovo_level.level2) 

                                         
# Define some colors
BLUE = (0, 0, 255)
RED = (255, 0, 0)
# def animation(i):
#     if i !=3 :
#         i+=1
#     else :
#         i= 1
def reset_sprite(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\crest_1.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\crest_2.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif  i == 9  :
        player.image = pygame.image.load(f"{path}\\crest_3.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    # elif i == 10:
    #     player.image = pygame.image.load(f"{path}\\crest_1.png")
    #     player.image = pygame.transform.scale (player.image, (50, 50))

def collision_all(a, b, speed):
    if a.colliderect(b):
        if a.x < b.x:
            a.x -= speed
        if a.x > b.x:
            a.x += speed
        if a.y < b.y:
            a.y -= speed
        if a.y > b.y:
            a.y += speed
    
def collision_sten(a, b, speed):
    if a.colliderect(b):
        if a.x < b:
            a.x -= speed
        elif a.x > b.PLATFORM_WIDTH:
            a.x += speed
        if a.y < b.PLATFORM_HEIGHT:
            a.y -= speed
        elif a.y > b.PLATFORM_HEIGHT:
            a.y += speed
def check_distance_atack(player,enemy):
        distance =((player.object[0] - enemy.object[0])**2 + (player.object[1] - enemy.object[1])**2)** 0.5
        if distance <= 85:
            return True
        else:
            return False
def check_distance_watch(player, enemy):
    distance = ((player.object[0] - enemy.object[0]) ** 2 + (player.object[1] - enemy.object[1])  ** 2) ** 0.5
    if distance <= 500:
        return True
    else:
        return False

                                                        
    
# level =  ([
#         "------------------------------------------------", 
#         "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwiwwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwxlwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwowwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "-wwwwwwwwwwwwwwwwwwtwwwwwwwwwwwwwwwwwwwwwwwwww-",
#         "------------------------------------------------"])      

# figovo_level.draw_level(level , Sten , platforms)

activ_pf2= []
d1 = figovo_level.Activ_click(500,500 , 'o' , 1 , figovo_level.level2 , 80 , 60 , 500 , 500)
activ_pf.append(d1)
d1_v =figovo_level.Activ_click(50,50 , 'o' , 1 , figovo_level.level3 , 80 , 60 , 50 , 50)
activ_pf2.append(d1_v)

level_glav = figovo_level.Level(figovo_level.level1 , enemy_massa1 , [] , 80 ,80)
level_interier_1 = figovo_level.Level(figovo_level.level2 , enemy_massa2 , [] , 60 ,60)

level_glav.massa_act.append(d1)
level_interier_1.massa_act.append(d1_v)

level_massa.append(level_glav)
level_massa.append(level_interier_1)
Level_now=level_glav
print(Entities)
figovo_level.level_reset(player , level_glav ,  Sten , platforms  ,Level_now , Entities )
# print(level_glav())
Sten.add(figovo_level.d1) 
Sten.add(figovo_level.d1_v)

entities.add(player) 

class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = pygame.Rect(0, 0, width, height)

    def apply(self, target):
   
        return target.object.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.object)

def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + SCREEN_WIDTH / 2, -t + SCREEN_HEIGHT / 2

    l = min(0, l)
    l = max(-(camera.width - SCREEN_WIDTH), l)
    t = max(-(camera.height - SCREEN_HEIGHT), t)
    t = min(0, t)

    return pygame.Rect(l, t, w, h)




total_level_width = len(figovo_level.level[0]) * PLATFORM_WIDTH
total_level_height = len(figovo_level.level) * PLATFORM_HEIGHT

camera = Camera(camera_configure, total_level_width, total_level_height)

################################################################################################################################################################################################################################################################################################################
while True:################################################################################################################################################################################################################################################################################################################
################################################################################################################################################################################################################################################################################################################    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key==pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
        
            if event.key == pygame.K_e:
                figovo_level.activate(player ,  Sten , platforms  ,Level_now , Entities , level_dict )
                print(Entities)#(figovo_level.activ_pf) , enemy_massa , Sten , platforms)
                reset = 2
    # for i in activ_pf :
    #         if level==level1:
    #             i.object.x = -100
    #             i.object.y = -100            
                
    # Draw everything
    screen.fill((48, 48, 47))
    # level_reset(reset , level ,  level_massa)
    # Move the player's cube
    # animation(i_s)
    # reset_sprite(i_s , player)
    keys = pygame.key.get_pressed()
    player.object.x += (keys[pygame.K_d] - keys[pygame.K_a]) * player.speed
    player.object.y += (keys[pygame.K_s] - keys[pygame.K_w]) * player.speed
    # animation(i_s)
    if i_s !=10 :
        i_s+=0.5
    else :
        i_s = 1
    reset_sprite(i_s , player)
    # Move the enemy cubes
    for enemy in enemy_massa:
        if reset == 1:
            if check_distance_watch(player, enemy):
                level_now.enemy.object.x += np.sign(player.object.x - enemy.object.x) * WALL_SPEED
                enemy.object.y += np.sign(player.object.y - enemy.object.y) * WALL_SPEED

    # Check for collisions between enemy cubes
    for i in range(len(enemy_massa)):
        for j in range(i + 1, len(enemy_massa)):
            collision_all(enemy_massa[i].object, enemy_massa[j].object, WALL_SPEED)

    # Check for collisions between the player and enemy cubes
    for enemy in enemy_massa:
        collision_all(enemy.object, player.object, WALL_SPEED)
        # wa
        collision_all(player.object, enemy.object, PLAYER_SPEED)
        if enemy is enemy:
            pass
        else :
            collision_all(enemy.object, enemy.object, WALL_SPEED)
  
    for enemy in enemy_massa:
                if check_distance_atack(player, enemy):
                    if  time_now - enemy.time_last > enemy.reload :           
                        player.health -= 5
                        print("Игрок получил урон!")
                        enemy.time_last=time_now
    # Check for player's attack
    if pygame.key.get_pressed()[pygame.K_r]:
        for enemy in enemy_massa:
            if player.object.colliderect(enemy.object) and player.object.distance_to(enemy.object) < 50:
                enemy.object.width -= 10
                enemy.object.height -= 10
    time_now = (time.time())

    # Выпуск шарика
    if keys[pygame.K_UP]:
        if quantity_balls > 0:
            if time_now-time_last_shoot > time_reload:
              
                ball = SNARYAD(speed_X=  0,speed_Y= -10)
                                                          
                balls.append(ball)
                entities.add(ball)
            
                time_last_shoot = time_now
                print(time_last_shoot)
                quantity_balls -= 1
                
    if keys[pygame.K_DOWN]:
        if quantity_balls > 0:
            if time_now-time_last_shoot > time_reload:
                
                ball = SNARYAD(speed_X=0,speed_Y=10)
                                                            
                balls.append(ball)
                entities.add(ball)
                time_last_shoot = time_now
                print(time_last_shoot)
                quantity_balls -= 1

    if keys[pygame.K_LEFT]:
        if quantity_balls > 0:
            if time_now-time_last_shoot>time_reload:
               
                ball = SNARYAD(speed_X =  -10,speed_Y=0)
                                                             
                balls.append(ball)
                entities.add(ball)
                time_last_shoot=time_now
                print(time_last_shoot)
                quantity_balls -=1
    
    if keys[pygame.K_RIGHT]:
        if quantity_balls > 0:
            if time_now-time_last_shoot>time_reload:
               
                ball=SNARYAD(speed_X = 10,speed_Y = 0)
                                                            
                balls.append(ball)
                entities.add(ball)
                time_last_shoot=time_now
                print(time_last_shoot)
                quantity_balls -=1

    for i in platforms:
        if i.colision :            
            collision_all(player.object, i.rect, PLAYER_SPEED)
            for enemy in enemy_massa:
                collision_all(enemy.object, i.rect, WALL_SPEED)
    # Обновление позиции шариков


    
    for ball in balls :
        ball.move()
    for enemy in enemy_massa:
        for ball in balls :
            
            if ball.rect.colliderect(enemy):
                enemy.health-=damage_player
                balls.remove(ball)
                entities.remove(ball)
                print("враг получил урон")

    for ball in balls:
        entities.remove(ball)
        entities.add(ball)

           
    if player.health <= 0:
        print("Игрок умер!")
        time.sleep(3)
        pygame.quit()
        sys.exit()

  
    

    
    kill_enemy=0

    for enemy in enemy_massa:
        if enemy.health <= 0 :#>
 
            print("враг умер")

            enemy_massa.remove(enemy)
            Entities.remove(enemy)
    for enemy in enemy_massa:

        Entities.remove(enemy)
        Entities.add(enemy) 
    
    if len(enemy_massa) <  figovo_enemy.enemy_life_max and len(enemy_massa) < 0 :
        if time_now-time_last_spawn>time_reload_enemy:
            if reset == 1:
                enemy_massa.append(figovo_enemy.NPS(pygame.Rect(random.randint(figovo_enemy.enemy_zona_x_min, figovo_enemy.enemy_zona_x_max), random.randint(figovo_enemy.enemy_zona_y_min, figovo_enemy.enemy_zona_y_max), 50, 50), 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],enemy.reload,enemy.time_last) )
                print("spawn")
                for i in enemy_massa:
                    i.object=i.rect
    
                time_last_spawn=time_now
                print (time_last_spawn)
    
    for e in Sten:
        screen.blit(e.image, camera.apply(e))         
    for e in entities:
        screen.blit(e.image, camera.apply(e))
    if reset == 1:
        for e in Entities:
            screen.blit(e.image, camera.apply(e))
    
    # for e in enemy_zona_massa:
    #     screen.blit(e, camera.apply(e))    

    camera.update(player)       
            
    counter_health_player = counter_health_player_shrift.render(f"health:{player.health}", False,
                  (0, 180, 0))
    screen.blit(counter_health_player, (10, 10))
    
    counter_balls_player = counter_health_player_shrift.render(f"balls:{quantity_balls}", False,
                  (0, 180, 0))
    screen.blit(counter_balls_player, (550, 10))

    pygame.display.flip()

    # Cap the frame rate
    pygame.time.Clock().tick(60)