import pygame
import os
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
path=str(os.getcwd())
i=1
# def animation(i):
#     if i !=3 :
#         i+=1
#     else :
#         i= 1
# def reset_sprite(i,player):
#     if i == 1 :
#         player.image = pygame.image.load(f"{path}\\crest_1.png")
#         player.image = pygame.transform.scale (player.image, (50, 50))
#     elif i == 2  :
#         player.image = pygame.image.load(f"{path}\\crest_2.png")
#         player.image = pygame.transform.scale (player.image, (50, 50))
#     else :
#         player.image = pygame.image.load(f"{path}\\crest_3.png")
#         player.image = pygame.transform.scale (player.image, (50, 50))






class Player (pygame.sprite.Sprite):
    def __init__(self, object, health, speed, pose,reload,time_last,image):
        pygame.sprite.Sprite.__init__( self )
        self.object = object
        self.health = health
        self.speed = speed
        self.pose = pose
        self.reload = reload
        self.time_last = time_last
        
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        self.image = pygame.image.load(f"{path}\\crest_{i}.png")#player.pngcop
        self.image = pygame.transform.scale (self.image, (50, 50))
        self.rect = pygame.Rect(1000, 50, 50, 50)

# while True:
#     animation(i)
#     reset_sprite(i, Player)





# player_cube = pygame.Rect(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, 50, 50,)#player_sprite((SCREEN_WIDTH / 2) , (SCREEN_HEIGHT / 2))
# player = Player(player_cube, 100, 5,[SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2], 0 , 0 , pygame.Surface((50, 50))  )
# player.object = player.rect

# player.object.center = (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)
      

