import pygame
import os
# import  figovo_17
import figovo_player 
import figovo_enemy
path=str(os.getcwd())
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
ICON_DIR = os.path.dirname(__file__) #  Полный путь к каталогу с файламиPLATFORM_WIDTH = 50

# activ_pf2= []
#import enemy_massa

# level_glav.massa_act.append(d1)
# level_interier_1.massa_act.append(d1_v)

# Level_now=level_glav
def check_distance_activate(play, pf):
        
        if pf.click:
            distance = ((play.object[0] - pf.rect[0]) ** 2 + (play.object[1] - pf.rect[1])  ** 2) ** 0.5
            if distance <= 60:
                print("activatre 'e' ")
            
                return True
        else:
            return False


            # enemy_massa.remove(enemy)
            # Entities.remove(enemy)
            # for i in platforms:
            #         Sten.remove(i)
            #         Sten.add(i)
            # print("activate")



class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y , col ):
        pygame.sprite.Sprite.__init__(self)
        
        # self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        # if col == "G":
        #     self.image = pygame.transform.scale (self.image, (1000, 1000))
        # else:
        #     self.object=pygame.Rect(x, y, 50,50)
        # self.image.fill(pygame.Color(PLATFORM_COLOR))
        
        if col == "-":
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\camen.png")#camen.pngplatform
            
            self.colision=True
            self.click=False
        if col == "i":
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\tree.png")
            
            self.colision=True
            self.click=False
        if col == "k" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\корыто.png")
            
            self.colision=True
            self.click=False
        if col == "U" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\Udochka-1.png")
            
            self.colision=True
            self.click=False
        if col == "b" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\пенёквтраве.png")
            
            self.colision=False
            self.click=False
        if col == "w" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            # if i_s !=10 :
            #     i_s+=0.25
            # else :
            #      i_s = 1
            self.image = pygame.image.load(f"{path}\\VODA.png")
            
            self.colision=True
            self.click=False
        if col == "W" :
            self.image = pygame.Surface((300, 1000))
            # if i_s !=10 :
            #     i_s+=0.25
            # else :
            #      i_s = 1
            self.image = pygame.image.load(f"{path}\\REKA.png")
            
            self.colision=True
            self.click=False
        # if col == "ф" :
        #     self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        #     self.image = pygame.image.load(f"{path}\\VODA_2.png")
            
        #     self.colision=False
        #     self.click=False
        if col == "o" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\междустенкаизбы.png")
            
            self.colision=True
            # self.rect =  pygame.Rect( x, y ,PLATFORM_WIDTH , PLATFORM_HEIGHT )
            self.click=True
        if col == "]" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\стенкаизбып.png")
            
            self.colision=True
            # self.rect =  pygame.Rect( x, y ,PLATFORM_WIDTH , PLATFORM_HEIGHT )
            self.click=True
        if col == "[" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\стенкаизбы.png")
            
            self.colision=True
            # self.rect =  pygame.Rect( x, y ,PLATFORM_WIDTH , PLATFORM_HEIGHT )
            self.click=True
        if col == "p" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\повозка.png")
            
            self.colision=False
            # self.rect =  pygame.Rect( x, y ,PLATFORM_WIDTH , PLATFORM_HEIGHT )
            self.click=True
        if col == "x" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\междукрыша.png")
            
            self.colision=True
            self.click=False
        if col == "п" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\крышаизбы.png")
            
            self.colision=True
            self.click=False
        if col == "л" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\крышаизбылев.png")
            
            self.colision=True
            self.click=False
        if col == "ш" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\крышаизбыдлябока.png")
            
            self.colision=True
            self.click=False
        if col == "s" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\сено_среднее.png")
            
            self.colision=True
            self.click=False
        if col == "S" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\сено_крыша.png")
            
            self.colision=True
            self.click=False
        if col == "c" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\сено_крышап.png")
            
            self.colision=True
            self.click=False
        if col == "B" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\берёза.png")
            
            self.colision=True
            self.click=False
        if col == "Z" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\Zabor.png")
            
            self.colision=True
            self.click=False
        if col == "z" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\Zabor_bok.png")
            
            self.colision=True
            self.click=False
        if col == "|" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\Zabor_bok_povorot.png")
            
            self.colision=True
            self.click=False
        if col == "l" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\стенкадверь.png")
            
            self.colision=True
            self.click=True
        if col == ";" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\стенкадверь2.png")
            
            self.colision=True
            self.click=False
        if col == "t" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\tropa.png")
            
            self.colision=False
            self.click=False
        if col == "6" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_stena.png")
            
            self.colision=True
            self.click=False
        if col == "8" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_stena_gr.png")
            
            self.colision=True
            self.click=False
        if col == "4" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_stena_vr.png")
            
            self.colision=True
            self.click=False
        if col == "1" :
            self.image = pygame.image.load(f"{path}\\zabor.png")
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.colision=True
            self.click=False
        if col == "2" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_stena4.png")
            
            self.colision=True
            self.click=False
        if col == "3" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_ugl1.png")
            
            self.colision=True
            self.click=False
        if col == "K" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\Kuzneca.png")
            
            self.colision=True
            self.click=True
        if col == "9" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_ugl2.png")
            
            self.colision=True
            self.click=False
        if col == "7" :
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.image = pygame.image.load(f"{path}\\interier_ugl3.png")
           
            self.colision=True
            self.click=False
        # if col == "1" :
        #     self.image = pygame.image.load(f"{path}\\interier_ugl4.png")
        #     self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        #     self.colision=True
        #     self.click=False
        if col == "5" :
            self.image = pygame.image.load(f"{path}\\interier_pol.png")
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.colision=False
            self.click=False

        if col == ")" :
            self.image = pygame.image.load(f"{path}\\заборбок2.png")
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.colision=True
            self.click=False 
        if col == "=" :
            self.image = pygame.image.load(f"{path}\\zabor.png")
            self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
            self.colision=True
            self.click=False     
            self.image = pygame.transform.scale (self.image, (50, 50))
        if col == "G" :
            self.image = pygame.Surface((1000, 1000))
            self.object = pygame.Rect(x, y, 1000,1000)
            self.image = pygame.image.load(f"{path}\\ground.png")
            
            self.colision=False
            self.click=False
        

  
     
        
        if col == "G" :
            self.image = pygame.transform.scale (self.image, (1000, 1000 ))
            self.rect = pygame.Rect(x, y, 1000, 1000)

        elif  col == "B" :
            self.image = pygame.transform.scale (self.image, (50, 100 ))
            self.rect = pygame.Rect(x, y, 20, 100)
        
        elif  col == "W" :
            self.image = pygame.transform.scale (self.image, (300, 1000 ))
            self.rect = pygame.Rect(x, y, 300, 1000)
        elif  col == "K" :
            self.image = pygame.transform.scale (self.image, (100, 100 ))
            self.rect = pygame.Rect(x, y, 100, 100)
        elif  col == "z" :
            self.image = pygame.transform.scale (self.image, (50, 50 ))
            self.rect = pygame.Rect(x, y, 10, 50)
        elif  col == "Z" :
            self.image = pygame.transform.scale (self.image, (50, 50 ))
            self.rect = pygame.Rect(x, y, 50, 20)
        elif  col == "|" :
            self.image = pygame.transform.scale (self.image, (50, 50 ))
            #self.image_rect = pygame.Rect(x, y, 50, 50)
            self.rect = pygame.Rect( x, y, (20 , 10) , (20,10))
            #self.collision_rect = pygame.Rect(x + 40, y, 10)
        else :
            self.image = pygame.transform.scale (self.image, (PLATFORM_WIDTH, PLATFORM_HEIGHT ))
            self.rect = pygame.Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)
           
class Activ_click(Platform):
    def __init__(self ,x , y ,col ,  number , level_number  ,  p_x , p_y , n_x , n_y , foto)   :
        Platform.__init__(self ,x , y ,col )
        self.number= number 
        self.level_number = level_number
        self.object = pygame.Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)
        self.p_x=p_x
        self.p_y=p_y 
        self.n_x = n_x
        self.n_y = n_y
        self.foto = foto
activ_pf = []
level_massa = []
reset=1
# class Level():
#     def __init__(self , level_map , massa_vr , massa_act , player_x , player_y):
#         self.level_map = level_map
#         self.massa_vr = massa_vr
#         self.massa_act = massa_act
#         self.player_x = player_x
#         self.player_y = player_y
#     # def enemy_massa(self , Enteties =pygame.sprite.Group()):
#     #     Enteties.add(self.massa_vr)

def draw_level( level , Sten , platforms , water_massa , reka_massa):
    
    # for pf in level:
        x = y = 0 # координаты
        for row in level.level_map: # вся строка
            for col in row: # каждый символ
                if  col != " ":
                    pf = Platform(x,y, col )
                    pf.object=pf.rect
                    # if col == "G" :
                    #     pf.image = pygame.transform.scale (pf.image, (1000, 1000))
                    Sten.add(pf)
                    platforms.append(pf)
                    # if pf.click:
                    #     activ_pf.append(pf)
                    if col == "w"  :
                        water_massa.append(pf)
                    if col == "W":
                        reka_massa.append(pf)

                x += PLATFORM_WIDTH #блоки платформы ставятся на ширине блоков
            y += PLATFORM_HEIGHT    #то же самое и с высотой
            x = 0                   #на каждой новой строчке начинаем с нуля
level1 = ([
        "------------------------------------------------",   
        "-G                  G                           -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                    6                          -",
        "-                                               -",
        "-                                               -",
        "-       6                                       -",
        "-                                               -",
        "-                                               -",
        "-                                               -",   
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -",
        "-                                               -"
        ])
level2 =([  
        "444444444444",
        "855555555558",
        "855555555558",
        "855555555558",
        "444444444444",
        ""])
level3 =([
        "",   
        "444444444444",
        "8555555555555555555558",
        "8555555555555555555558",
        "8555555555555555555558",
        "444444444444",
        ""])
level = ([
        "------------------------------------------------",   
        "-Gwww-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-www-",
        "-",
        "------------------------------------------------" ])
    
level_d = ([
            "---------------------------------------------------------------------------------------------------------------------",
            "G                   G                  G                   G                   G   W                                          G                             G                             ",
            "                                ttttttttttttttttttttttttttttttttttttttttt                                                                                                                      ",
            "                              ttzлxп z      zлxп z      t     Ssc       t                                                                                                    ",
            "                       K    tt  z[ol z      z[ol z      t  k  [ol   B   t                                                                                                    ",
            "                       ttttt   ZZZZZZZ      ZZZZZZ      t               t                                                                                                     ",
            "                    B       tt zлxп  z           B      t      B        t         w                                                                                         ",
            "                              tt[olk z      B           t         B     t         w                                                                                          ",
            "                         p      tt   z         B        t   B           t                                                                                                    ",
            "                                  tt    t  k            t         лxп   tлxп                                                                                                 ",
            "                                    tt  t          B    t  p   k  [ol   t[ol                                                                                                 ",
            "                                      ttttttttttttttttttttttttttttttttttt                                                                                                    ",
            "      B                B                t     B   ZZZZZZt               t   k                                                                                               ",
            "                                        tZZZz     zлшxп t          лп   t                                                                                                   ",
            "             B                     B    tлxпz     z[ool tлxп       [l   t                                                                                                  ",
            "      B                                 t;o]z     ZZZZZZt[ol  B         t        www                                                                                       ",
            "     B BB                               tZZZz           t               t         ww                                                                                       ",
            "  BB  B  B                   B          t           p   t         B     tлxп                                                                                                ",
            "    B   B  B                            t      B        t               t[ol      U                                                                                         ",
            "      B  BB                             tZZZZz     B   Gt   B   B       t         k                                                                                        ",
            "     B                                  tzSscz          tлxп            t                                                                                                  ",
            "G                   G                  Gtz[olz          t[olG           t  G      wW           G                                       G                                   ",            
            "                                        t   ZZZZz       t   ZZZZz       t                                                                                                   ",
            "                                        t   zлxпz       t   zSscz       t                                                                                                   ",
            "                                        t   k[olz       t   z[olz    k  t                                                                                                   ",
            "                                        ttttttttttttttttttttttttttttttttt                                                                                                             ",
            "                                        t               t  G        ZZZZt                                                                                                  ",
            "                                  B     t           лxп t           zлxпtk                                                                                                 ",
            "                                        t       B   [ol t       B   z[olt                                                                                                  ",
            "                                        tZZZZz       k  t           ZZZZt                                                                                                  ",
            "                                        t лxпz    B     tлxп            t          ww                                                                                      ",
            "                                        t [olz          t[ol            t                                                                                                  ",
            "                                        tk   z          t    k          t                                                                                                  ",
            "                                         t  ZZZZ        tZZZZ    ZZZZZZZt         ww                                                                                       ",
            "                                          t лxпzZZZZz   tSscz    zлxп  t                                                                                                  ",
            "                                           t[olz лxпz   t[olz    k[ol t                                                                                                  ",
            "                                            t    [olz   tZZZZ    t             w                                                                                    ",
            "                                             tttttttttttttttttttttttt                                                                                                        ",          
            "G                    G                 G           t       G                G      W            G                                       G                          "            
            
            
            ])
print(f"level type - {type(level_d)}")


level_massa.append(level1 )
level_massa.append(level2) 
# d1 = Activ_click(500,500 , 'o' , 1 , level2 , 80 , 60 , 500 , 500)
# activ_pf.append(d1)
# d1_v =Activ_click(50,50 , 'o' , 1 , level3 , 80 , 60 , 50 , 50)
# activ_pf.append(d1_v)
# # def level_reset( player , level_class , Sten , platforms , level_now ,Entities ,enemy_massa):#level , level_ , Platform , Sten , platforms , x_p, y_p , player
#     print(f"level_clas == {level_class}")
#     for _ in range(10):
#         for i in platforms:
#             platforms.remove(i)
#             Sten.remove(i)
        
#         print(f"plat: {platforms}")
#         if len(level_now) > 0 :
#             for row in level_now.level_map:
#                 for col in row:
#                     for i in col:
#                         col.replace(i ,"" )
#     enemy_massa = level_class.massa_vr
#     level_now = level_class
#     # print(f"level_now :{level_now}")
    
#     print(f"massa_vr in massa == {enemy_massa}")
#     print(f"massa_vr in class == {level_class.massa_vr}")
    
#     # print(f"massa_vr in class in object == {level_now.massa_vr.object}")
#     # for enemy in enemy_massa:

        
#     #     Entities.add(enemy)
#     #     print(f'Group e = {Entities}')
#     #     print(f'enemy = {enemy}')
#     # level_class.enemy_massa(Entities)
#     # reset_enemy_massa(enemy_massa , level_class.massa_vr)    
#     # reset_activ_pf(activ_pf , level_class.massa_act)
#     for enemy in enemy_massa:
#         enemy.object = enemy.rect
#         print(f"rect enemy = {enemy.object}")
#         Entities.add(enemy)
#     print(len(enemy_massa))     
#     print(f"level_now = {level_now}")
#     draw_level(level_now , Sten , platforms)
#     player.object.x = level_class.player_x#figovo_player.
#     player.object.y = level_class.player_y#figovo_player.
#     print(len(enemy_massa))


# def activate(player , Sten , platforms ,level_now , Entities , level_dict , enemy_massa):#activ_pf , enemy_massa , Sten , platforms 
#     # for level_ in Level_now.massa_act : 
#         for pf in  level_now.massa_act:
#             if check_distance_activate(player , pf):
#                 print(level_dict[pf.level_number])
#                 figovo_17.level_reset(player ,level_dict[pf.level_number], Sten , platforms  , level_now ,  Entities , enemy_massa)# , Platform , Sten , platforms level , pf.level_number , Platform , Sten , platforms ,  pf.p_x , pf.p_y , player
#                 # if len(enemy_massa)>0:
#                 #     # for enemy in figovo_enemy.enemy_massa:
#                 #     #     enemy.health = 0 #>c
#                 #     #     # print(enemy_massa)
#                 #     #     # enemy_massa.remove(enemy)
#                 #     #     print("враг умер")


# def reset_enemy_massa(enemy_massa , enemy_massa_number):
#     enemy_massa == enemy_massa_number

# def reset_activ_pf(activ_pf , activ_pf_number):
#     activ_pf == activ_pf_number

def reset_level_platform(platform):
    for i in platform:
        platform.remove(i)
# level_c_1 = Level(level1 , enemy) 

# d1 = Activ_click(500,500 , 'o' , 1 , level2 , 80 , 60 , 500 , 500)

# d1_v =figovo_level.Activ_click(50,50 , 'o' , 1 , "level_glav" , 80 , 60 , 50 , 50)


# level_glav =  Level(level1 , enemy_massa1 , [] , 80 ,80)
# level_interier_1 = Level(figovo_level.level2 , enemy_massa2 , [] , 60 ,60)
# level_dict = {"level_glav" = level_glav





    