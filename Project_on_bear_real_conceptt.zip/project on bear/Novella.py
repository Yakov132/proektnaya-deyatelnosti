#Novella.py
import pygame
import sys

# Инициализация Pygame
pygame.init()

# Настройки экрана
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Визуальная новелла")

# Цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
People_name = "starosta"
# Шрифты
font = pygame.font.Font(None, 36)

# Класс для управления состоянием игры
class GameState:
    def __init__(self):
        self.current_scene = 0
        # People_name = "starosta"
        if People_name == "starosta" : 
            self.scenes = [     
                    {
                        "text": "Привет! Это моя деревня!",
                        "choices": ["Алекс", "Мария"],
                        "next": [1, 2],
                        "mission":[None]
                    },
                    {
                        "text": "Приятно познакомиться, Алекс!",
                        "choices": ["Продолжить"],
                        "next": [4],
                        "mission":[None]
                    },
                    {
                        "text": "Приятно познакомиться, Мария!",
                        "choices": ["Продолжить"],
                        "next": [3],
                        "mission":[None]
                    },

                    {
                        "text": "Это конец истории.",
                        "choices": ["Выход"],
                        "next": [None],
                        "mission":[None]
                    },
                    {
                        "text": "пока - пока",
                        "choices": ["Выход"],
                        "next": [None],
                        "mission":["Kill_10_noliver"]
                    }
                    
                ]
        if People_name == "vilage" :
                self.scenes = [ 
             
                {
                    "text": "Привет! Как тебя зовут?",
                    "choices": ["Алекс", "Мария"],
                    "next": [1, 2],
                    "mission":[None]
                },
                {
                    "text": "Приятно познакомиться, Алекс!",
                    "choices": ["Продолжить"],
                    "next": [4],
                    "mission":[None]
                },
                {
                    "text": "Приятно познакомиться, Мария!",
                    "choices": ["Продолжить"],
                    "next": [3],
                    "mission":[None]
                },

                {
                    "text": "Это конец истории.",
                    "choices": ["Выход"],
                    "next": [None],
                    "mission":[None]
                },
                {
                    "text": "эээ мысайд , ээээ мфто , эээээ гэпэчко !",
                    "choices": ["Выход"],
                    "next": [None],
                    "mission":[None]
                }
               
            ]

    def get_current_scene(self):
        return self.scenes[self.current_scene]

    def choose(self, choice_index):
        next_scene = self.get_current_scene()["next"][choice_index]
        if next_scene is not None:
            self.current_scene = next_scene
        else:
            pygame.quit()
            sys.exit()

# Основной цикл игры
def main():
    game_state = GameState()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    game_state.choose(0)
                elif event.key == pygame.K_2 and len(game_state.get_current_scene()["choices"]) > 1:
                    game_state.choose(1)
                elif event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

        # Отрисовка сцены
        screen.fill(WHITE)
        current_scene = game_state.get_current_scene()
        text_surface = font.render(current_scene["text"], True, BLACK)
        screen.blit(text_surface, (50, 50))

        # Отображение вариантов выбора
        for i, choice in enumerate(current_scene["choices"]):
            choice_surface = font.render(f"{i + 1}. {choice}", True, BLACK)
            screen.blit(choice_surface, (50, 100 + i * 40))

        pygame.display.flip()

if __name__ == "__main__":
    main()