#include <iostream>

int main() {
    setlocale(LC_ALL , "RU");
    for (int i = 0 ; i < 10 ; i++){
        std::cout << i <<std::endl;
    }

}