import pygame
import random
import os

PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

path=str(os.getcwd())

# enemy_zona_x_min= 50 
# enemy_zona_x_max = 100
# enemy_zona_y_min = 50
# enemy_zona_y_max = 100

enemy_life_max = 2
enemy_life= 2
enemy_life_sneek = 3

class NPC(pygame.sprite.Sprite):
    def __init__(self,people_image ,  x , y , object, health, speed, pose, dialog_image = (f"{path}\\cop.png") , people_name=None):#,reload,time_last
        pygame.sprite.Sprite.__init__(self)
        self.people_image = people_image
        self.x = x
        self.y = y
        self.object = object
        self.health = health
        self.speed = speed
        self.pose = pose
        self.people_name = people_name
        # self.time_last=time_last
        
        # self.rect= pygame.Rect(x, y, 50, 50)
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        self.image = pygame.image.load(f"{path}\\{people_image}.png")#enemy.pngalian
        self.image = pygame.transform.scale (self.image, (50, 50))
        self.rect = pygame.Rect(x, y, 50, 50)
        self.dialog_image = dialog_image 
    def sprite_killer(sprite_):
        sprite_.kill()




# enemy_cubes = ([pygame.Rect(random.randint(enemy_zona_x_min, enemy_zona_x_max), random.randint(enemy_zona_y_min, enemy_zona_y_max), 50, 50)]for _ in range(enemy_life) )
# enemy_massa = [NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes]
enemy_zona_massa=[]
# enemy_zona_massa.append(enemy_zona_x_min)
# enemy_zona_massa.append(enemy_zona_x_max)
# enemy_zona_massa.append(enemy_zona_y_min)
# enemy_zona_massa.append(enemy_zona_y_max)