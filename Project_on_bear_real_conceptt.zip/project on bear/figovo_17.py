
#figovo-17
import pygame
import random
import sys
import numpy as np
import time
import os
import figovo_level 
import figovo_player
import figovo_enemy
import People 
import figovo_bear 
import json 

pygame.init()

# Set up the screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PLAYER_SPEED = 5
WALL_SPEED = 1
RED = "RED"
BLUE = (0, 0, 255)
YELLOW = (209, 178, 23)
GREY = (130, 129, 122)
BALL_COLOR = (255, 0, 0)
BALL_RADIUS = 5
BACKGROUND_COLOR = "GREEN"
path=str(os.getcwd())
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
screen.fill(BACKGROUND_COLOR)
i_s = 1
objects_ = []
balls = []
# animation_set = [pygame.image.load(f"r{i}.png") for i in range(1, 6)]
time_now=         1729865614.3516421  #(time.time())
print(time_now)
time_reload=      0.5
time_last_shoot=    0
enemy_massa = []
damage_player=50
quantity_balls=100
time_last_spawn=0
time_reload_enemy=5
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
PLATFORM_COLOR = "#FF6262"
ICON_DIR = os.path.dirname(__file__) #  Полный путь к каталогу с файлами
Entities = pygame.sprite.Group() # Все объекты
Sten = pygame.sprite.Group() # Все объекты
level_now = []
activ_pf = []
level_massa = []
reka_massa =  []
# reset=1
people_for_dialog = []
enemy_zona_x_min= 50 
enemy_zona_x_max = 100
enemy_zona_y_min = 50
enemy_zona_y_max = 100
enemy_life = 2

# Рядом с другими переменными спавна врагов
time_last_spawn_bear = 0
time_reload_bear = 10  # Медведи реже спавнятся
max_bears = 3  # Максимальное количество медведей
bear_spawn_zones = [  # Зоны спавна медведей
    {"x_min": 500, "x_max": 1000, "y_min": 1000, "y_max": 1500},
    {"x_min": 3000, "x_max": 3500, "y_min": 500, "y_max": 1000},
    {"x_min": 2000, "x_max": 2500, "y_min": 2000, "y_max": 2500}
]

counter_health_player_shrift = pygame.font.SysFont('serif', 28)
entities = pygame.sprite.Group() # Все объекты
platforms = [] # то, во что мы будем врезаться или опираться
untities = pygame.sprite.Group()
enemy_life_max = 2
enemy_life= 2
enemy_life_sneek = 3  
spawn = "yes"
povorot = True
player_cube = pygame.Rect(1000, 100, 50, 50,)#player_sprite((SCREEN_WIDTH / 2) , (SCREEN_HEIGHT / 2))
player = figovo_player.Player(player_cube, 100, 5,[SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2], 0 , 0 , pygame.Surface((50, 50))  )
player.object = player.rect
name = "menu"
menu_image = pygame.image.load('menu_test.jpg')
# dog_surf.set_colorkey((255, 255, 255))                                                                 <- нужно для убирания  белого заднего фонаЕсли поверхность была создана на базе изображения с альфа-каналом, то вместо convert() надо использовать метод convert_alpha(), так как первый удаляет прозрачные пиксели (вместо них будет черный цвет). Таким образом, код загрузки и обработки изображений разных форматов должен выглядеть примерно так:
menu_image_new = pygame.transform.scale (menu_image, (SCREEN_WIDTH , SCREEN_HEIGHT))
font = pygame.font.SysFont('Arial', 35)
font_1 = pygame.font.SysFont('Arial', 17)
font_for_dialog = pygame.font.SysFont('Arial', 12)
font_for_dialog_1 = pygame.font.SysFont('Arial', 12)
objects = []
People_name = "деревенщина"
Kill_chert = 0
Gold = 0
inventory = []
inventory.append(Gold)
class GameState:
    def __init__(self , people):
        self.current_scene = 0
        # People_name = "starosta"
        if people.people_name == "староста" :
            if not Kill_chert  > 10 :
                self.scenes = [    
                        
                            
                            {
                                "text": "Здравствуй путник , что тебя привело сюда ?",
                                "choices": ["Приключения", "Деньги"],
                                "next": [1, 2],
                                "mission":[None]
                            },
                            {
                                "text": "Приятно слышать , раньше , когда был моложе,\n отправлялся в путешествия !",
                                "choices": ["Продолжить"],
                                "next": [4],
                                "mission":[None]
                            },
                            {
                                "text": "Нам таких не надо ...",
                                "choices": ["Продолжить"],
                                "next": [3],
                                "mission":[None]
                            },

                            {
                                "text": "Уходи",
                                "choices": ["Выход"],
                                "next": [None],
                                "mission":[None]
                            },
                            {
                                "text": "Если ты хочешь приключений , тогда у меня есть просьба для тебя...",
                                "choices": ["Какая ?" , "Я пока занят..."],
                                "next": [5 , None],
                                "mission":[None]
                            },
                            {
                                "text": "В последнее время развелось много нечисти на западе ...",
                                "choices": ["Продолжить"],
                                "next": [6 , None],
                                "mission":[None]
                            },
                            {
                                "text": "Предлагаю тебе уменшить их количество , готов ?",
                                "choices": ["Я готов !" , "Нет, я небуду таким заниматься !", "А что ине за это будет ?"],
                                "next": [7 , 8 , 9],
                                "mission":[None]
                            },
                            {
                                "text": "Очень хорошо ... Ладно , мне надо идти",
                                "choices": ["Досвидания"],
                                "next": [None],
                                "mission":['Kill_5_noliver']
                            },
                            {
                                "text": "Жаль, что в тебе мало храбрости ,я пойду...",
                                "choices": ["Досвидания"],
                                "next": [None],
                                "mission":[None]
                            },
                            {
                                "text": "Хм... Дай подумать , я тебе могу дать небольшую плату.",
                                "choices": ["Я согласен!" , "Нет , для меня мало, пока."],
                                "next": [7 , 8],
                                "mission":[None]
                            }
                    
                    
                            ]
            else:
                
                self.scenes = [    
                        
                            
                            {
                                "text": "Здравствуй путник...",
                                "choices": ["Продолжить"],
                                "next": [1],
                                "mission":[None]
                            },
                            {
                                "text": "Вижу, ты справился, вот твоя плата",
                                "choices": ["Спасибо, досвидания !"],
                                "next": [ None],
                                "mission":[None],
                                
                            }
              
                    
                    
                    ]

        if people.people_name == "деревенщина" :
                self.scenes = [ 
             
                {
                    "text": "Привет! Как тебя зовут?",
                    "choices": ["Не знаю", "А ты кто ?"],
                    "next": [1, 2]
                },
                {
                    "text": "Тогда ладно ...",
                    "choices": ["Продолжить"],
                    "next": [4]
                },
                {
                    "text": "Я обычный крестьянин .",
                    "choices": ["Продолжить"],
                    "next": [3]
                },

                {
                    "text": "Понятно",
                    "choices": ["Выход"],
                    "next": [None]
                },
                {
                    "text": "Я пойду по делам , пока !",
                    "choices": ["Выход"],
                    "next": [None]
                }
               
            ]
    if Kill_chert >=10:
        Gold +=10
    def get_current_scene(self):
        return self.scenes[self.current_scene]

    def choose(self, choice_index):
        next_scene = self.get_current_scene()["next"][choice_index]
        if next_scene is not None:
            self.current_scene = next_scene
        else:
            # pygame.quit()
            # sys.exit()
            global quit_dialog_button
            quit_dialog_button = False
def spawn_bears(bear_massa, Entities, current_time):
    """Спавнит новых медведей если нужно"""
    global time_last_spawn_bear
    
    # Проверяем нужно ли спавнить и прошло ли время перезарядки
    if len(bear_massa) < max_bears and current_time - time_last_spawn_bear > time_reload_bear:
        
        # Выбираем случайную зону спавна
        zone = random.choice(bear_spawn_zones)
        
        # Создаем нового медведя
        bear_rect = pygame.Rect(
            random.randint(zone["x_min"], zone["x_max"]),
            random.randint(zone["y_min"], zone["y_max"]), 
            50, 50
        )
        bear = figovo_bear.Bear(bear_rect, 150, 2, [zone["x_min"], zone["y_min"]], 2, 0)
        bear.object = bear.rect
        bear_massa.append(bear)
        Entities.add(bear)
        
        time_last_spawn_bear = current_time
        print(f"Заспавнен новый медведь! Всего медведей: {len(bear_massa)}")

def novella():
        game_state = GameState()    
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        game_state.choose(0)
                    elif event.key == pygame.K_2 and len(game_state.get_current_scene()["choices"]) > 1:
                        game_state.choose(1)
                    elif event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        sys.exit()

            # Отрисовка сцены
            screen.fill(WHITE)
            current_scene = game_state.get_current_scene()
            text_surface = font.render(current_scene["text"], True, BLACK)
            screen.blit(text_surface, (50, 50))

            # Отображение вариантов выбора
            for i, choice in enumerate(current_scene["choices"]):
                choice_surface = font.render(f"{i + 1}. {choice}", True, BLACK)
                screen.blit(choice_surface, (50, 100 + i * 40))

            pygame.display.flip()
            
def save_json(name_people , value):
    with open("Dialog_list.json" , "r" , encoding = "utf-8") as file :
        
        
        if value == "dialognik" :
            list_dialog_words = json.load(file)
            dialog_words = list_dialog_words["people"][name_people]
            return dialog_words
        if value == "otvet" :
            list_dialog_words = json.load(file)
            dialog_words = list_dialog_words["otvet"][name_people]
            return dialog_words
        if value == "otvetnik" :
            list_dialog_words = json.load(file)
            dialog_words = list_dialog_words["otvetnik"][name_people]
            return dialog_words
# def save_json(name_people , value):
#     with open("Dialog_list.json" , "r" , encoding = "utf-8") as file :
#         if value == "староста" :

class Button():
    def __init__(self, x, y, width, height,  massa , font_x ,buttonText='Button', onclickFunction=False, onePress=False ):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.massa = massa
        self.onclickFunction = onclickFunction
        self.onePress = onePress
        # self.people=None
        
        self.fillColors = {
            'normal': '#ffffff',
            'hover': '#666666',
            'pressed': '#333333',
        }

        self.buttonSurface = pygame.Surface((self.width, self.height))
        self.buttonRect = pygame.Rect(self.x, self.y, self.width, self.height)

        self.buttonSurf = font_x.render(buttonText, True, (20, 20, 20))

        self.alreadyPressed = False

        
        massa.append(self)
    def process(self, *args):
        people=False
        for arg in args:
            people=arg

        mousePos = pygame.mouse.get_pos()
        
        self.buttonSurface.fill(self.fillColors['normal'])
        if self.buttonRect.collidepoint(mousePos):
            self.buttonSurface.fill(self.fillColors['hover'])

            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                self.buttonSurface.fill(self.fillColors['pressed'])

                if self.onePress:
                    if people:
                        self.onclickFunction(people)
                    else:
                        self.onclickFunction()

                elif not self.alreadyPressed:

                    if people:
                        self.onclickFunction(people)
                    else:
                        self.onclickFunction()
                    self.alreadyPressed = True

            else:
                self.alreadyPressed = False

        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
            self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)

def dialog(player , people_massa , massa_dialog):
    for people in people_massa:
        if check_distance_atack(player , people):
            print('dialog - True')
            for Button in massa_dialog :
                
                Button.process(people)
            
            return  people
      


def myFunction():
    print('Button Pressed')
    global NAME
    NAME = "main"
   
quit_dialog_button = True
def Quit_dialog_function():
    global quit_dialog_button
    quit_dialog_button = False
foward_dialog_button = True
def foward_dialog ():
 
    global foward_dialog_button
    foward_dialog_button = False
def Dialog_window(people):
    print("Dialog_print")
    surf = pygame .Surface((700, 500))  # при создании передается размер
    surf.fill((128, 128, 128))
    surf.set_alpha(200)
    ava_surf = pygame.image.load(people.dialog_image)#(f"{path}\\cop.png")#)
    ava_rect = pygame.Rect(10 , 10 , 100 ,100  )
    ava_surf = pygame.transform.scale (ava_surf, (120, 120))
    screen.blit(ava_surf, ava_rect)
    dialog_words = save_json(people.people_name , "dialognik")
    otvet_words = save_json(people.people_name , "otvet")
    screen.blit(surf, (60, 30))  # при размещении указываются координаты
    screen.blit(ava_surf, ava_rect)
    
    Button(500, 400, 100, 50, massa_in_dialog ,(pygame.font.SysFont('Arial', 20)) , otvet_words ,foward_dialog )
    People_name = (people.people_name)
     #starosta"
    
    font_for_dialog = pygame.font.SysFont('Arial', 40)
    global quit_dialog_button
    # while quit_dialog_button:
    #     for i in pygame.event.get():
    #         if i.type == pygame.QUIT:
    #             sys.exit()
    #     for i in massa_in_dialog:
    #         i.process()
    #     counter_dialog_words = font_for_dialog.render(f"{people.people_name}: {dialog_words}", False,
    #             (0,0,0))
    #     screen.blit(counter_dialog_words, (100, 100))
    #     if foward_dialog_button == False:
    #         people.otvet =save_json(people.people_name , "otvetnik")
    #         counter_dialog_otvet = font_for_dialog.render(f"{people.people_name}: {people.otvet}", False,
    #             (0,0,0))
    #         screen.blit(counter_dialog_otvet, ((100), 200))
      
    #     pygame.display.update()
    game_state = GameState(people)    
    while quit_dialog_button:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    game_state.choose(0)
                elif event.key == pygame.K_2 and len(game_state.get_current_scene()["choices"]) > 1:
                    game_state.choose(1)
                elif event.key == pygame.K_ESCAPE:
                    # pygame.quit()
                    quit_dialog_button = False
                    # sys.exit()

        # Отрисовка сцены
        screen.fill(WHITE)
        current_scene = game_state.get_current_scene()
        # if (len.current_scene["text"]) > 5 :
        text_surface = font_for_dialog.render(current_scene["text"], True, BLACK)
        screen.blit(text_surface, (70, 220))
        # else :
        #     text_surface = font_for_dialog.render(current_scene["text"], True, BLACK)
        #     screen.blit(text_surface, (250, 50))

        # Отображение вариантов выбора
        for i, choice in enumerate(current_scene["choices"]):
            choice_surface = font_for_dialog.render(f"{i + 1}. {choice}", True, BLACK)
            screen.blit(choice_surface, (100, 350 + i * 40))
        screen.blit(ava_surf, ava_rect)
        pygame.display.flip()
     
    quit_dialog_button = True   

    
massa_dialog = []
massa_in_dialog = []
customButton = Button(225, 150, 400, 100, objects ,font ,  'Играть',  myFunction)

Quit_dialog = Button(100, 500, 100, 50, massa_in_dialog ,font_for_dialog ,'Закончить диалог',  Quit_dialog_function)
quit_interier_watch_button= Button(100, 500, 100, 50, massa_in_dialog ,font_for_dialog ,'Выйти из дома',  Quit_dialog_function)

for i in massa_dialog :

    print (f"Massa_dialog = {i.height}")


player.object.x = 2050
player.object.y = 1200
people_massa = [People.NPC( "крестьянин" , 170 , 600 , (pygame.Rect( 50,50 , 50, 50)) ,100, 5 , (50,50) , (f"{path}\\ава_крестьянин.png") , "деревенщина"  ),
People.NPC( "крестьянинсветлый" , 1700 , 600 , (pygame.Rect( 1700,50 , 50, 50)) ,100, 5 , (50,50) ,"деревенщина"),
People.NPC( "крестьянинсветлыймирор" , 2050 , 1100 , (pygame.Rect( 1700,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянин" , 2050 , 150 , (pygame.Rect( 1600,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") , "деревенщина"),
People.NPC( "староста" , 1500 , 150 , (pygame.Rect( 1700,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"староста" ),
People.NPC( "крестьянка" , 1550 , 150 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крнстьянканью" , 1850 , 150 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянканьюмирор" , 3000 , 700 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянинсерый" , 2100, 1350 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянинсветлыймирор" , 2690, 1450 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянка" , 2950, 1600 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина"),
People.NPC( "крестьянканьюмирор" , 3400, 1800 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянин" , 3050, 1970 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянинмирор" , 2100, 1650 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50) ,(f"{path}\\cop.png") ,"деревенщина"),
People.NPC( "крестьянка" , 3050, 500 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50) ,(f"{path}\\ава_крестьянин.png") ,"деревенщина"),
People.NPC( "крестьянканьюмирор" , 3700, 650 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянинсветлыймирор" ,4050, 650  , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50),(f"{path}\\ава_крестьянин.png") ,"деревенщина" ),
People.NPC( "крестьянинсерыймирор" , 3650, 1250 , (pygame.Rect( 1750,50 , 50, 50)) ,100, 5 , (50,50) ,(f"{path}\\ава_крестьянин.png") ,"деревенщина"),]



bochka_massa = []
bochka_1 = People.NPC( "бочка" , 1700 , 700 , (pygame.Rect( 50,50 , 50, 50)) ,100, 5 , (50,50) )
bochka_massa.append(bochka_1)
water_massa = []
Button_dialog = Button(30, 50, 100, 50, massa_dialog ,font_1 ,'Разговаривать', Dialog_window)

enemy_cubes1 = ([pygame.Rect(random.randint(figovo_enemy.enemy_zona_x_min, figovo_enemy.enemy_zona_x_max), random.randint(figovo_enemy.enemy_zona_y_min, figovo_enemy.enemy_zona_y_max), 50, 50)]for _ in range(enemy_life) )
enemy_massa1 = [figovo_enemy.NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes1]

bear1 = ([pygame.Rect(random.randint(500, 1000), random.randint(1000,1500), 50, 50)]for _ in range(figovo_enemy.enemy_life) )
bear_massa = [figovo_bear.Bear(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in bear1]
 


 
# Set up the title of the windows
pygame.display.set_caption("Russain Game")


class Level():
    def __init__(self , level_map , massa_vr , massa_act ,level_people_massa,level_bochka_massa,  player_x , player_y):
        self.level_map = level_map
        self.massa_vr = massa_vr
        self.massa_act = massa_act
        self.level_people_massa = level_people_massa 
        self.level_bochka_massa =level_bochka_massa
        self.player_x = player_x
        self.player_y = player_y


class SNARYAD(pygame.sprite.Sprite):
    def __init__(self, speed_X, speed_Y ):
        pygame.sprite.Sprite.__init__( self )


        self.speed_X=speed_X
        self.speed_Y=speed_Y
                
        self.image = pygame.Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT ))
        self.image.fill(pygame.Color(PLATFORM_COLOR))
        self.image = pygame.image.load(f"{path}\\fireball.png")
        self.image = pygame.transform.scale (self.image, (25, 25))
        self.object=self.rect = pygame.Rect(player.object[0] + player.object[2] // 2,
                                              player.object[1] + player.object[3] // 2, 5,5) #pygame.Rect(x_c, y_c, 5, 5)
     
    def move(self):
        self.rect[0] += self.speed_X
        self.rect[1] += self.speed_Y
COLOR =  "#888888"  
class Level_class():
    def __init__ (self , mapa , number):
        self.mapa = mapa
        self.number = number







for i in enemy_massa:
    i.object = i.rect
   
    Entities.add(i)
    objects_.append(i)
def draw_circle(x,y):
    pygame.draw.circle(screen,(0, 0, 255), (x_c, y_c),40)
    if pygame.key.get_pressed()[pygame.K_UP]:
        x_c += x
        y_c += y
    if pygame.key.get_pressed()[pygame.K_DOWN]:
        x_c += x
        y_c += y


                                         
# Define some colors
BLUE = (0, 0, 255)
RED = (255, 0, 0)

def reset_sprite(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\crest_3.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 3  :
        player.image = pygame.image.load(f"{path}\\crest_2.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\crest_3.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif  i == 9  :
        player.image = pygame.image.load(f"{path}\\crest_2.png")
        player.image = pygame.transform.scale (player.image, (50, 50))

def reset_sprite_p(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\crest_3p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 3  :
        player.image = pygame.image.load(f"{path}\\crest_2p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\crest_3p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif  i == 9  :
        player.image = pygame.image.load(f"{path}\\crest_2p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
def reset_sprite_stay(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\crest_1.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\crest_stay_2.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif  i == 9  :
        player.image = pygame.image.load(f"{path}\\crest_stay_3.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
def reset_sprite_stay_p(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\crest_1p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\crest_stay_2p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif  i == 9  :
        player.image = pygame.image.load(f"{path}\\crest_stay_3p.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
def reset_sprite_water(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\VODA.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\VODA_2.png")
        player.image = pygame.transform.scale (player.image, (50, 50))
def reset_sprite_reka(i,player):
    if  i==1 :
        player.image = pygame.image.load(f"{path}\\REKA_2.png")

    elif    i == 6  :
        player.image = pygame.image.load(f"{path}\\REKA.png")

  
def collision_all(a, b, speed):
    if a.colliderect(b):
        if a.x < b.x:
            a.x -= speed
        if a.x > b.x:
            a.x += speed
        if a.y < b.y:
            a.y -= speed
        if a.y > b.y:
            a.y += speed
    
def collision_sten(a, b, speed):
    if a.colliderect(b):
        if a.x < b:
            a.x -= speed
        elif a.x > b.PLATFORM_WIDTH:
            a.x += speed
        if a.y < b.PLATFORM_HEIGHT:
            a.y -= speed
        elif a.y > b.PLATFORM_HEIGHT:
            a.y += speed
def check_distance_atack(player,enemy):
        distance =((player.object[0] - enemy.object[0])**2 + (player.object[1] - enemy.object[1])**2)** 0.5
        if distance <= 85:
            return True
        else:
            return False
def check_distance_watch(player, enemy):
    distance = ((player.object[0] - enemy.object[0]) ** 2 + (player.object[1] - enemy.object[1])  ** 2) ** 0.5
    if distance <= 500:
        return True
    else:
        return False

def level_reset( player , level_class , Sten , platforms , level_now ,Entities ,enemy_massa , water_massa , reka_massa):#level , level_ , Platform , Sten , platforms , x_p, y_p , player
    print(f"level_clas == {level_class}")
    for _ in range(10):
        for i in platforms:
            platforms.remove(i)
            Sten.remove(i)
        
    
        if len(level_now.level_map) > 0 :
            for row in level_now.level_map:
                for col in row:
                    for i in col:
                        col.replace(i ,"" )
    
    level_now = level_class

    figovo_level.draw_level(level_now , Sten , platforms , water_massa , reka_massa)

    return  level_now  #, enemy_massa

def activate(player , Sten , platforms ,level_now , Entities , level_dict , enemy_massa , spawn ,activ_pf , water_massa , reka_massa):#activ_pf , enemy_massa , Sten , platforms 
    # for level_ in Level_now.massa_act :  
        for pf in  level_now.massa_act:
            print(f"lelev_ nowka = {level_now}")
            if figovo_level.check_distance_activate(player , pf):

                level_reset(player ,level_dict[pf.level_number], Sten , platforms  , level_now ,  Entities , enemy_massa ,water_massa)# ,figovo_17. Platform , Sten , platforms level , pf.level_number , Platform , Sten , platforms ,  pf.p_x , pf.p_y , player
                if level_dict[pf.level_number] == level_interier_1 :
                    spawn = "no"
                    enemy_massa = []
                    for i in level_now.massa_act :
                        Sten.remove(i)
                    for i in level_now.level_people_massa :
                        Sten.remove(i)
                    for i in level_now.level_bochka_massa :
                        Sten.remove(i)
                    activ_pf = [figovo_level.Activ_click(50,50 , 'l' , 1 , "level_glav" , 80 , 60 , 50 , 50)]#level_interier_1.massa_act
                    for i in level_interier_1.massa_act:
                        Sten.add(i)
                    for i in level_interier_1.level_people_massa:
                        Entities.add(i)
                    for i in level_interier_1.level_bochka_massa :
                        Entities.add(i)     
                    people_massa = level_interier_1.level_people_massa
                    bochka_massa = level_interier_1.level_bochka_massa
                    print (f" return = {enemy_massa},{spawn},{activ_pf}")
                    return enemy_massa , spawn ,[figovo_level.Activ_click(50,50 , 'l' , 1 , "level_glav" , 80 , 60 , 50 , 50)] #activ_pf #, people_massa ,bochka_massa
                elif level_dict[pf.level_number] == level_glav :

                    spawn = "yes"
                    enemy_massa = level_glav.massa_vr 
                    for i in level_now.massa_act :
                        Sten.remove(i)
                    activ_pf = level_glav.massa_act#
                    print(level_glav.massa_act)
                    for i in activ_pf:
                        Sten.add(i)
                    print("D4C")
                    people_massa = level_glav.level_people_massa
                    bochka_massa = level_glav.level_bochka_massa
                    print (f"{enemy_massa},{spawn},{activ_pf}")
                    return enemy_massa , spawn , activ_pf #,people_massa , bochka_massa
             

enemy_cubes = ([pygame.Rect(random.randint(1, 2), random.randint(1, 2), 50, 50)]for _ in range(2) )
enemy_massa_i = [figovo_enemy.NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes]

activ_pf2= []
d1 = figovo_level.Activ_click(1650,350 , 'o' , 1 , "level_2"  , 80 , 60 , 500 , 500 , (f"{path}\\In_dom.jpeg") )
d2 = figovo_level.Activ_click(1350,320 , 'K' , 1 , "level_2"  , 80 , 60 , 450 , 450 , (f"{path}\\кузницавнутри.jpeg") )
d1_v =figovo_level.Activ_click(50,50 , 'Z' , 1 , "level_glav" , 80 , 60 , 50 , 50 ,(f"{path}\\Zabor.png") )
activ_pf2.append(d1_v)
activ_pf.append(d2)
activ_pf.append(d1)
level_glav = Level(figovo_level.level_d ,([figovo_enemy.NPS(enemy_cube, 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],2,0   ) for enemy_cube in enemy_cubes]), [] , [people_massa[0]] , [bochka_1] ,80 ,80)
level_glav.massa_vr = enemy_massa_i
level_interier_1 = Level(figovo_level.level2 , [] , [] ,[] , [], 60 ,60)

level_interier_1.massa_act.append(d1_v)
level_glav.massa_act.append(d1  )
level_glav.massa_act.append(d2 )
level_dict = {
    "level_glav" : level_glav ,
    "level_2" : level_interier_1


    }
NAME = "menu"
enemy_massa = level_glav.massa_vr
level_now = level_glav 

print(f"level_glav.massa_vr == {level_glav.massa_vr}")

level_reset(player , level_glav , Sten , platforms  ,level_now, Entities , enemy_massa , water_massa , reka_massa) #enemy_massa , activ_pf) figovo_level.
level_now = level_glav
print(len(enemy_massa))
print(f"level_now = {level_now}")

#def click_pf(level_now):
#    for pf in platforms:
#        if  figovo_level.check_distance_activate(player , pf) and pf.click==True:
#                        Interier_watch(pf)
Sten.add(d1) 
Sten.add(d2)
entities.add(player)

for enemy in enemy_massa:
    enemy.object = enemy.rect
    Entities.add(enemy)

for people in people_massa :
    people.object = people.rect
    Entities.add(people)

for bochka in bochka_massa :
    bochka.object = bochka.rect
    Entities.add(bochka)

for people in bear_massa :
    people.object = people.rect
    Entities.add(people)

class Camera(object):
    def __init__(self, camera_func, width, height):
        self.camera_func = camera_func
        self.state = pygame.Rect(0, 0, width, height)

    def apply(self, target):
   
        return target.object.move(self.state.topleft)

    def update(self, target):
        self.state = self.camera_func(self.state, target.object)

def camera_configure(camera, target_rect):
    l, t, _, _ = target_rect
    _, _, w, h = camera
    l, t = -l + SCREEN_WIDTH / 2, -t + SCREEN_HEIGHT / 2

    l = min(0, l)
    l = max(-(camera.width - SCREEN_WIDTH), l)
    t = max(-(camera.height - SCREEN_HEIGHT), t)
    t = min(0, t)

    return pygame.Rect(l, t, w, h)




total_level_width = len(figovo_level.level[0]) * PLATFORM_WIDTH
total_level_height = len(figovo_level.level) * PLATFORM_HEIGHT

camera = Camera(camera_configure, total_level_width+1000000, total_level_height+1000000)
random_move = 0    
         
time_now_walk = 1729865614.3516421               
time_last_walking = 0
time_reload_walk = 0.75
random_move = 2


def Interier_watch(pf):
                print("Dialog_print")
                surf = pygame .Surface((700, 500))  # при создании передается размер
                surf.fill((128, 128, 128))
                surf.set_alpha(200)
                

                screen.blit(surf, (60, 30))  # при размещении указываются координаты
                
                ava_surf = pygame.image.load(pf.foto)#(f"{path}\\cop.png")#)

                ava_rect = pygame.Rect(10 , 10 , SCREEN_WIDTH ,SCREEN_HEIGHT )
                ava_surf = pygame.transform.scale (ava_surf, (SCREEN_WIDTH ,SCREEN_HEIGHT ))
                
            
                #starosta"
                
                font_for_dialog = pygame.font.SysFont('Arial', 40)
                global quit_interier_watch_button
                # while quit_dialog_button:
                #     for i in pygame.event.get():
                #         if i.type == pygame.QUIT:
                #             sys.exit()
                #     for i in massa_in_dialog:
                #         i.process()
                #     counter_dialog_words = font_for_dialog.render(f"{people.people_name}: {dialog_words}", False,
                #             (0,0,0))
                #     screen.blit(counter_dialog_words, (100, 100))
                #     if foward_dialog_button == False:
                #         people.otvet =save_json(people.people_name , "otvetnik")
                #         counter_dialog_otvet = font_for_dialog.render(f"{people.people_name}: {people.otvet}", False,
                #             (0,0,0))
                #         screen.blit(counter_dialog_otvet, ((100), 200))
                
                #     pygame.display.update()
                quit = True    
                while quit:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                # pygame.quit()
                            # quit_dialog_button = False
                                    quit = False
                                # sys.exit()

                    # Отрисовка сцены
                    screen.fill(WHITE)
                    screen.blit(ava_surf, ava_rect)
                    # if (len.current_scene["text"]) > 5 :
                    
                    #     text_surface = font_for_dialog.render(current_scene["text"], True, BLACK)
                    #     screen.blit(text_surface, (250, 50))

                    # Отображение вариантов выбора
                    # for i, choice in enumerate(current_scene["choices"]):
                    #     choice_surface = font_for_dialog.render(f"{i + 1}. {choice}", True, BLACK)
                    #     screen.blit(choice_surface, (100, 350 + i * 40))
                    
                    pygame.display.flip()
                
                # quit_interier_watch_button = True          
                quit=True
def click_pf(pf):
    for pf in platforms:
        if  figovo_level.check_distance_activate(player , pf) and pf.click==True:
                print("Dialog_print")
                surf = pygame .Surface((700, 500))  # при создании передается размер
                surf.fill((128, 128, 128))
                surf.set_alpha(200)
                

                screen.blit(surf, (60, 30))  # при размещении указываются координаты
                
                ava_surf = pygame.image.load(f"{path}\\In_dom.png")#)

                ava_rect = pygame.Rect(10 , 10 , SCREEN_WIDTH ,SCREEN_HEIGHT )
                ava_surf = pygame.transform.scale (ava_surf, (SCREEN_WIDTH ,SCREEN_HEIGHT ))
                
            
                #starosta"
                
                font_for_dialog = pygame.font.SysFont('Arial', 40)
                global quit_interier_watch_button
                # while quit_dialog_button:
                #     for i in pygame.event.get():
                #         if i.type == pygame.QUIT:
                #             sys.exit()
                #     for i in massa_in_dialog:
                #         i.process()
                #     counter_dialog_words = font_for_dialog.render(f"{people.people_name}: {dialog_words}", False,
                #             (0,0,0))
                #     screen.blit(counter_dialog_words, (100, 100))
                #     if foward_dialog_button == False:
                #         people.otvet =save_json(people.people_name , "otvetnik")
                #         counter_dialog_otvet = font_for_dialog.render(f"{people.people_name}: {people.otvet}", False,
                #             (0,0,0))
                #         screen.blit(counter_dialog_otvet, ((100), 200))
                
                #     pygame.display.update()
                quit = True    
                while quit:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_ESCAPE:
                                # pygame.quit()
                            # quit_dialog_button = False
                                    quit = False
                                # sys.exit()

                    # Отрисовка сцены
                    screen.fill(WHITE)
                    screen.blit(ava_surf, ava_rect)
                    # if (len.current_scene["text"]) > 5 :
                    
                    #     text_surface = font_for_dialog.render(current_scene["text"], True, BLACK)
                    #     screen.blit(text_surface, (250, 50))

                    # Отображение вариантов выбора
                    # for i, choice in enumerate(current_scene["choices"]):
                    #     choice_surface = font_for_dialog.render(f"{i + 1}. {choice}", True, BLACK)
                    #     screen.blit(choice_surface, (100, 350 + i * 40))
                    
                    pygame.display.flip()
                
                # quit_interier_watch_button = True          
                quit=True
################################################################################################################################################################################################################################################################################################################
while  NAME == "menu":################################################################################################################################################################################################################################################################################################################
################################################################################################################################################################################################################################################################################################################    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.blit(menu_image_new , (0,0))
    for object in objects:
        object.process()
        print(object)
     

    pygame.display.update()


################################################################################################################################################################################################################################################################################################################
while NAME == "main":################################################################################################################################################################################################################################################################################################################
################################################################################################################################################################################################################################################################################################################    
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key==pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
        
            if event.key == pygame.K_e:
                # print(f"level_now.massa_act = {level_now.massa_act}")
                # for pf in  level_now.massa_act: 
                #     print(f"D4C = {pf}")
                #     print(f"D4C = {pf.rect.x , pf.rect.y }") 
                #     print(player.object.x , player.object.y) 
                #     print (((player.object[0] - pf.rect[0]) ** 2 + (player.object[1] - pf.rect[1])  ** 2) ** 0.5) 
                #     if True:#figovo_level.check_distance_activate(player , pf):
                #         print(f" pf = {pf}")
                #         for i in range(len(enemy_massa)):
                #             for enemy in enemy_massa:
                        
                #                 print("враг умер")

                #                 enemy_massa.remove(enemy)
                #                 Entities.remove(enemy)
                #         print (f" return_! = {enemy_massa},{spawn},{activ_pf}")
                #         enemy_massa , spawn , level_now.massa_act  = activate(player ,  Sten , platforms  ,level_now , Entities , level_dict , enemy_massa , spawn , activ_pf , water_massa)#(figovo_level.activ_pf) , enemy_massa , Sten , platforms)
                #         #w, level_people_massa , level_bochka_massa
                #         print(f"enemy posle activate ={enemy_massa}")
                for pf in  level_now.massa_act:
                    if figovo_level.check_distance_activate(player , pf):
                        Interier_watch(pf)
                click_pf(level_now)        
            if event.key == pygame.K_p:
                print(f"player_pose = {player.object.x,player.object.y}")   
               
    
    # Draw everything
    screen.fill((48, 48, 47))

    keys = pygame.key.get_pressed()
    player.object.x += (keys[pygame.K_d] - keys[pygame.K_a]) * player.speed
    player.object.y += (keys[pygame.K_s] - keys[pygame.K_w]) * player.speed

    if i_s !=10 :
            i_s+=0.25
    else :
        i_s = 1
    if keys[pygame.K_d]:# or  keys[pygame.K_s] or keys[pygame.K_w] :
        povorot = True
        reset_sprite(i_s , player)
    elif keys[pygame.K_a]:# or keys[pygame.K_s] or keys[pygame.K_w] :
        povorot = False
        reset_sprite_p(i_s , player)
    elif keys[pygame.K_s] or keys[pygame.K_w] :
        if povorot == True :
            reset_sprite(i_s , player)
        elif povorot == False :
            reset_sprite_p(i_s , player)
    else :
        if povorot == True :
            reset_sprite_stay(i_s , player)
        elif povorot == False :
            reset_sprite_stay_p(i_s , player)
    for i in water_massa :

        reset_sprite_water( i_s , i )
    
    for i in  reka_massa :
        reset_sprite_reka(i_s , i)         
            
    # Move the enemy cubes
    for enemy in enemy_massa:
            if check_distance_watch(player, enemy):
                enemy.object.x += np.sign(player.object.x - enemy.object.x) * WALL_SPEED
                enemy.object.y += np.sign(player.object.y - enemy.object.y) * WALL_SPEED
    
    # Check for collisions between enemy cubes
    for i in range(len(enemy_massa)):
        for j in range(i + 1, len(enemy_massa)):
            collision_all(enemy_massa[i].object, enemy_massa[j].object, WALL_SPEED)

    # Check for collisions between the player and enemy cubes
    for enemy in enemy_massa:
        collision_all(enemy.object, player.object, WALL_SPEED)
        # wa
        collision_all(player.object, enemy.object, PLAYER_SPEED)
        if enemy is enemy:
            pass
        else :
            collision_all(enemy.object, enemy.object, WALL_SPEED)
    for people in people_massa:
        for enemy in enemy_massa:
            collision_all(people.object, enemy.object, WALL_SPEED)

        collision_all(player.object, people.object, PLAYER_SPEED)
        if people is people:
            pass
        else :
            collision_all(people.object, people.object, WALL_SPEED)
    for people in bochka_massa:
        for enemy in enemy_massa:
            collision_all(people.object, enemy.object, WALL_SPEED)
        collision_all(people.object, player.object, WALL_SPEED)
        # wa
        collision_all(player.object, people.object, PLAYER_SPEED)
        if people is people:
            pass
        else :
            collision_all(people.object, people.object, WALL_SPEED)

    # В основном игровом цикле (после движения врагов)
    for bear in bear_massa:
        # Обновляем AI медведя
        bear.update_ai(player, platforms, bear_massa, time_now)
    
        # Проверяем атаку медведя
        bear.attack_player(player, time_now)
    
    # Проверяем столкновения с игроком
        collision_all(bear.object, player.object, bear.speed)
        collision_all(player.object, bear.object, PLAYER_SPEED)
    for enemy in enemy_massa:
        if check_distance_atack(player, enemy):
            if  time_now - enemy.time_last > enemy.reload :           
                player.health -= 5
                print("Игрок получил урон!")
                enemy.time_last=time_now
    # Check for player's attack
    if pygame.key.get_pressed()[pygame.K_r]:
        for enemy in enemy_massa:
            if player.object.colliderect(enemy.object) and player.object.distance_to(enemy.object) < 50:
                enemy.object.width -= 10
                enemy.object.height -= 10
    time_now = (time.time())

    # Выпуск шарика
    if keys[pygame.K_UP]:
        if quantity_balls > 0:
            if time_now-time_last_shoot > time_reload:
            
                ball = SNARYAD(speed_X=  0,speed_Y= -10)
                                                        
                balls.append(ball)
                entities.add(ball)
            
                time_last_shoot = time_now
                print(time_last_shoot)
                quantity_balls -= 1
                
    if keys[pygame.K_DOWN]:
        if quantity_balls > 0:
            if time_now-time_last_shoot > time_reload:
                
                ball = SNARYAD(speed_X=0,speed_Y=10)
                                                            
                balls.append(ball)
                entities.add(ball)
                time_last_shoot = time_now
                print(time_last_shoot)
                quantity_balls -= 1

    if keys[pygame.K_LEFT]:
        if quantity_balls > 0:
            if time_now-time_last_shoot>time_reload:
            
                ball = SNARYAD(speed_X =  -10,speed_Y=0)
                                                            
                balls.append(ball)
                entities.add(ball)
                time_last_shoot=time_now
                print(time_last_shoot)
                quantity_balls -=1
    
    if keys[pygame.K_RIGHT]:
        if quantity_balls > 0:
            if time_now-time_last_shoot>time_reload:
            
                ball=SNARYAD(speed_X = 10,speed_Y = 0)
                                                            
                balls.append(ball)
                entities.add(ball)
                time_last_shoot=time_now
                print(time_last_shoot)
                quantity_balls -=1

    for i in platforms:
        if i.colision :            
            collision_all(player.object, i.rect, PLAYER_SPEED)
            for enemy in enemy_massa:
                collision_all(enemy.object, i.rect, WALL_SPEED)
            for people in people_massa:
                collision_all(people.object, i.rect, PLAYER_SPEED)
            for people in bochka_massa:
                collision_all(people.object, i.rect, PLAYER_SPEED)
    # Обновление позиции шариков

    time_now_walk = (time.time())
    if time_now_walk-time_last_walking > time_reload_walk:
        for people in people_massa :

            if random_move == 6 :
                vibor = random.randint(0 ,2)

                if vibor == 0 :
                    people.rect.y += -20
                    random_move = 2
                if vibor == 1 :
                    people.rect.y += 20
                    random_move = 8
                if vibor == 2 :
                    people.rect.x += 20
                    random_move = 6

            elif  random_move == 2 :
                vibor = random.randint(0 ,2)

                if vibor == 0 :
                    people.rect.x += -20
                    random_move = 4
                if vibor == 1 :
                    people.rect.x += 20
                    random_move = 6
                if vibor == 2 :
                    people.rect.y += 20
                    random_move = 2

            elif  random_move == 4 :
                vibor = random.randint(0 ,2)

                if vibor == 0 :
                    people.rect.y += -20
                    random_move = 8
                if vibor == 1 :
                    people.rect.y += 20
                    random_move = 2
                if vibor == 2 :
                    people.rect.x += -20
                    random_move = 4

            elif  random_move == 8 :
                vibor = random.randint(0 ,2)

                if vibor == 0 :
                    people.rect.x += -20
                    random_move = 4
                if vibor == 1 :
                    people.rect.x += 20
                    random_move = 6
                if vibor == 2 :
                    people.rect.y += -20
                    random_move = 8


        time_last_walking = time_now_walk
        print(f"walking = {time_last_walking}")
    
    for ball in balls :
        ball.move()
        for bear in bear_massa:
            for ball in balls[:]:  # Используем копию списка для безопасного удаления
                if ball.rect.colliderect(bear.rect):
                    bear.health -= damage_player
                    balls.remove(ball)
                    entities.remove(ball)
                    print(f"Медведь получил урон! Здоровье: {bear.health}")
                    break  # Прерываем внутренний цикл после попадания
    for enemy in enemy_massa:
        for ball in balls :
            
            if ball.rect.colliderect(enemy):
                enemy.health-=damage_player
                balls.remove(ball)
                entities.remove(ball)
                print("враг получил урон")

    for ball in balls:
        entities.remove(ball)
        entities.add(ball)

        
    if player.health <= 0:
        print("Игрок умер!")
        time.sleep(3)
        pygame.quit()
        sys.exit()


    

    
    kill_enemy=0

    for enemy in enemy_massa:
        if enemy.health <= 0 :#>

            print("враг умер")
            Kill_chert += 1
            enemy_massa.remove(enemy)
            Entities.remove(enemy)

    for bear in bear_massa[:]:  # Используем копию списка для безопасного удаления
        if bear.health <= 0:
            print("Медведь умер!")
            #Kill_chert += 1
            bear_massa.remove(bear)
            Entities.remove(bear)
            # Если хочешь чтобы медведи давали награду, добавь здесь:
            Gold += 15  # Медведи дают больше золота
    
    for enemy in enemy_massa:

        Entities.remove(enemy)
        Entities.add(enemy) 

    if len(enemy_massa) < 3   and spawn == "yes" :
        print(f"time_now ={time_now}")

        if time_now-time_last_spawn>time_reload_enemy:
            
            enemy_massa.append(figovo_enemy.NPS(pygame.Rect(random.randint(1, 2), random.randint(1 , 2), 50, 50), 100, 3,[SCREEN_WIDTH / 4, SCREEN_HEIGHT / 4],enemy.reload,enemy.time_last) )
            print("spawn")
            for i in enemy_massa:
                i.object=i.rect

            time_last_spawn=time_now
            print (time_last_spawn)
    if spawn == "yes":  # Только если спавн вообще включен
        spawn_bears(bear_massa, Entities, time_now)
        
    for e in Sten:
        screen.blit(e.image, camera.apply(e))         
    for e in entities:
        screen.blit(e.image, camera.apply(e))

    for e in Entities:

        screen.blit(e.image, camera.apply(e))
    
   
     
    camera.update(player)       
            
    counter_health_player = counter_health_player_shrift.render(f"health:{player.health}", False,
                (0, 180, 0))
    screen.blit(counter_health_player, (10, 10))
    
    counter_balls_player = counter_health_player_shrift.render(f"balls:{quantity_balls}", False,
                (0, 180, 0))
    screen.blit(counter_balls_player, (550, 10))

    counter_Gold = counter_health_player_shrift.render(f"Gold:{Gold}", False,
                (0, 180, 0))
    screen.blit(counter_Gold, (10, 50))

    people_for_dialog = dialog(player , people_massa , massa_dialog)

    pygame.display.flip()

    # Cap the frame rate
    pygame.time.Clock().tick(60)

