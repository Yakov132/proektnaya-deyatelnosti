#Test Dialog
import pygame
import random
import sys
import numpy as np
import time
import os
import figovo_level 
import figovo_player
import figovo_enemy
import People 
import figovo_bear 
import json
pygame.init()
BACKGROUND_COLOR = "GREEN"
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
path=str(os.getcwd())
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
screen.fill(BACKGROUND_COLOR)
objects = []
massa_in_dialog = []
font_for_dialog = pygame.font.SysFont('Arial', 12)
pygame.init()
def Quit_dialog_function():
    quit_dialog_button == False
def save_json(name_people , value):
    with open("Dialog_list.json" , "r" , encoding = "utf-8") as file :
        if value == "староста" :
            list_dialog_words = json.load(file)
            dialog_words = list_dialog_words["староста"]["dialogs"][list_dialog_words["староста"]["dialogs_id"]]
            return dialog_words
def rename_id( dialog_id , new_id):
      dialog_id = new_id
      return dialog_id
def create_button(text , quantity_button ,dialog_id , new_id ):
    for i in range(quantity_button):
        dialog_button_change_{i} =  Button(100, 500, 100, 50, massa_in_dialog ,font_for_dialog ,text, rename_id( dialog_id , new_id) )


def myFunction(people):
    
    surf = pygame .Surface((700, 500))  # при создании передается размер
    surf.fill((128, 128, 128))
    surf.set_alpha(200)
    ava_surf = pygame.image.load(people.dialog_image)#(f"{path}\\cop.png")#)
    ava_rect = pygame.Rect(70 , 60 , 50 ,50  )
    ava_surf = pygame.transform.scale (ava_surf, (50, 50))
    screen.blit(ava_surf, ava_rect)
    # dialog_words = save_json(people.people_name , "dialognik")
    # otvet_words = save_json(people.people_name , "otvet")
    screen.blit(surf, (60, 30))  # при размещении указываются координаты
    screen.blit(ava_surf, ava_rect)
    
    massa_in_dialog = []
    Quit_dialog = Button(100, 500, 100, 50, massa_in_dialog ,font_for_dialog ,'Закончить диалог',  Quit_dialog_function)
    with open("Dialog_list.json" , "r" , encoding = "utf-8") as file :
        if people.value == "староста" :
            list_dialog_words = json.load(file)
            dialog_words = list_dialog_words["староста"]["dialogs"][list_dialog_words["староста"]["dialogs_id"]]
    text_dialog = dialog_words
    button_dialog = Button(100, 500, 100, 50, massa_in_dialog ,font_for_dialog ,{text_dialog},  rename_id)
    font_for_dialog = pygame.font.SysFont('Arial', 50)
    font = pygame.font.SysFont('Arial', 40)
    counter_text_dialog = font.render(f'{text_dialog}', False,(0, 180, 0)) 
    global quit_dialog_button
    while quit_dialog_button:
        for i in pygame.event.get():
            if i.type == pygame.QUIT:
                sys.exit()
            screen.blit((), (10, 10))
            # screen.blit(counter_dialog_otvet, ((100), 200))
        for object in massa_in_dialog:
            object.process()
            print(object)
        pygame.display.update()


###############################################################################################################################################################
class Button():
    def __init__(self, x, y, width, height,  massa , font_x ,buttonText='Button', onclickFunction=False, onePress=False ):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.massa = massa
        self.onclickFunction = onclickFunction
        self.onePress = onePress
        # self.people=None
        
        self.fillColors = {
            'normal': '#ffffff',
            'hover': '#666666',
            'pressed': '#333333',
        }

        self.buttonSurface = pygame.Surface((self.width, self.height))
        self.buttonRect = pygame.Rect(self.x, self.y, self.width, self.height)

        self.buttonSurf = font_x.render(buttonText, True, (20, 20, 20))

        self.alreadyPressed = False

        
        massa.append(self)
    def process(self, *args):
        people=False
        for arg in args:
            people=arg

        mousePos = pygame.mouse.get_pos()
        
        self.buttonSurface.fill(self.fillColors['normal'])
        if self.buttonRect.collidepoint(mousePos):
            self.buttonSurface.fill(self.fillColors['hover'])

            if pygame.mouse.get_pressed(num_buttons=3)[0]:
                self.buttonSurface.fill(self.fillColors['pressed'])

                if self.onePress:
                    if people:
                        self.onclickFunction(people)
                    else:
                        self.onclickFunction()

                elif not self.alreadyPressed:

                    if people:
                        self.onclickFunction(people)
                    else:
                        self.onclickFunction()
                    self.alreadyPressed = True

            else:
                self.alreadyPressed = False

        self.buttonSurface.blit(self.buttonSurf, [
            self.buttonRect.width/2 - self.buttonSurf.get_rect().width/2,
            self.buttonRect.height/2 - self.buttonSurf.get_rect().height/2
        ])
        screen.blit(self.buttonSurface, self.buttonRect)
###############################################################################################################################################################
font = pygame.font.SysFont('Arial', 40)
# font_for_dialog = pygame.font.SysFont('Arial', 50)
people_massa = [People.NPC( "крестьянин" , 170 , 600 , (pygame.Rect( 50,50 , 50, 50)) ,100, 5 , (50,50) , (f"{path}\\cop.png") , "деревенщина"  )]
customButton = Button(225, 150, 400, 100, objects ,font,  'Играть',  myFunction)



    #  quit_dialog_button = True   




################################################################################################################################################################################################################################################################################################################
while True:################################################################################################################################################################################################################################################################################################################
################################################################################################################################################################################################################################################################################################################    
# Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key==pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
        # Draw everything
    screen.fill((48, 48, 47))
    # screen.blit(BACKGROUND_COLOR, (0,0))
    for object in objects:
        object.process()
        print(object)



    pygame.display.update()