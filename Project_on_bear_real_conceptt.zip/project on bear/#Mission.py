#Mission
Mission_now = []
Mission_complet = []
Mission = []
class Mission_work:
    def __init__(self , task):
        self.task = task
        