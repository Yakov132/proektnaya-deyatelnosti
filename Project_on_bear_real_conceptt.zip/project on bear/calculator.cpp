#include <iostream>

int main() {
    setlocale(LC_ALL , "RU");

    setlocale(LC_ALL , "RU");
    int n = 1;
    while (n <= 10) {
        std::cout << n << "\t" << n * n << "\n";  // выводим число и его квадрат через табуляцию
        ++n;
    }
}