import random

import pygame
#############################import os

# настройка папки ассетов
#############################game_folder = os.path.dirname(__file__)

# функция для установки случайно позиции переданого спрайта
def set_random_pos(sprite):
    pass

#pygame.init()

#SCREEN_SIZE = SCREEN_WIDTH, SCREEN_HEIGHT = 800, 800
#screen = pygame.display.set_mode(SCREEN_SIZE)
clock = pygame.time.Clock()
WIN_WIDTH = 1890 #Ширина создаваемого окна
WIN_HEIGHT = 980 # Высота
DISPLAY = (WIN_WIDTH, WIN_HEIGHT) # Группируем ширину и высоту в одну переменную
BACKGROUND_COLOR = "GREEN"


pygame.init() # Инициация PyGame, обязательная строчка 
screen = pygame.display.set_mode(DISPLAY) # Создаем окошко
pygame.display.set_caption("Super Mario Boy") # Пишем в шапку
bg = pygame.Surface((WIN_WIDTH,WIN_HEIGHT)) # Создание видимой поверхности
                                         # будем использовать как фон
bg.fill(BACKGROUND_COLOR)     # Заливаем поверхность сплошным цветом

class Platform(sprite.Sprite):
    def __init__(self, x, y):
        sprite.Sprite.__init__(self)
        self.image = Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(Color(PLATFORM_COLOR))
        self.rect = Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)


PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "BLACK"









# группа спрайтов
all_sprite = pygame.sprite.Group()
BLOCKs= pygame.sprite.Group()


#спрайт машины
car =  pygame.sprite.Sprite(all_sprite) 
car.image = pygame.image.load(f'car.png')
new_width = car.image.get_width() // 3


# спрайт персонажа
player = pygame.sprite.Sprite(all_sprite) 
player.image = pygame.image.load(f'alien.png')
player.rect = player.image.get_rect()  
player.rect.x = 50
player.rect.y = 50

entities = pygame.sprite.Group() # Все объекты
platforms = [] # то, во что мы будем врезаться или опираться
entities.add(player)



# спрайт монетки
coin = pygame.sprite.Sprite(all_sprite) 
coin.image = pygame.image.load(f'coin.png')
coin.rect =coin.image.get_rect()
coin.rect.x = 140
coin.rect.y = 60



new_height = car.image.get_height() // 3

car.image = pygame.transform.scale(car.image, (new_width, new_height))
#new_car = pygame.transform.scale(car, (23, 50))
car.rect =car.image.get_rect()
car.rect.x = 160
car.rect.y = 70

BLOCK = pygame.sprite.Sprite(BLOCKs) 
BLOCK.image = pygame.image.load(f'BLOCK.png')
BLOCK.rect =BLOCK.image.get_rect()
#.rect.x = 140
#.rect.y = 60



level = [
       "-------------------------",   
       "-                       -",
       "-    -                  -",
       "-                       -",
       "-   ----     --         -",
       "-                       -",
       "--                      -",
       "-                       -",
       "-                   --- -",
       "-                       -",
       "-                       -",
       "-      ---              -",
       "-                       -",
       "-   -----------         -",
       "-                       -",
       "-                -      -",
       "-                   --  -",
       "-                       -",
       "-          ----------   -",
       "-------------------------"]


class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((PLATFORM_WIDTH, PLATFORM_HEIGHT))
        self.image.fill(PLATFORM_COLOR)
        self.rect = pygame.Rect(x, y, PLATFORM_WIDTH, PLATFORM_HEIGHT)







# скорость движения
speed = 10

run = True
while run:
    screen.fill((0, 0, 64))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    
    screen.blit(bg, (0,0))  
    #screen.blit(pf,(x,y))#.image ,)#(50,50)) 

    x=y=0 # координаты
    for row in level: # вся строка
        for col in row: # каждый символ
            if col == "-":
              #создаем блок, заливаем его цветом и рисеум его
                pf = pygame.Surface((PLATFORM_WIDTH,PLATFORM_HEIGHT))
                pf.fill("BLACK") 
                screen.blit(pf,(x,y))
                    
            x += PLATFORM_WIDTH #блоки платформы ставятся на ширине блоков
        y += PLATFORM_HEIGHT    #то же самое и с высотой
        x = 0                   #на каждой новой строчке начинаем с нуля

    # управление персонажем
   

        # обработка клавиатуры
    keybord_keys = pygame.key.get_pressed()
    if keybord_keys[pygame.K_w] :#and player.rect.top :#> 0:
        player.rect.y -= speed
    if keybord_keys[pygame.K_s] :#and player.rect.bottom: #< SCREEN_HEIGHT:
        player.rect.y += speed
    if keybord_keys[pygame.K_a]:# and player.rect.left:# > 0:
        player.rect.x -= speed
    if keybord_keys[pygame.K_d]:# and player.rect.right: #< SCREEN_WIDTH:
        player.rect.x += speed


        #all_sprite.draw(screen)

   
        

    
    
    # проверка касания спрайтов (колайд)
    colide=pygame.sprite.collide_mask(player,coin)
    #colide_player=pygame.sprite.collide_mask(player)
    
    #print(colide)
    if colide:#==True:
        coin.rect.x = random.randint(50,400)
        coin.rect.y = random.randint(50,400)
        
        
    
    # отрисовка спрайтов
    all_sprite.draw(screen)
    
    pygame.display.update()
    clock.tick(30)

pygame.quit()
